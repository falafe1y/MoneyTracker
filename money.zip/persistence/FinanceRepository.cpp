#include "FinanceRepository.h"

#include "../core/Currency.h"

#include <QDir>
#include <QJsonDocument>
#include <QJsonArray>
#include <QFileInfo>
#include <QSqlError>
#include <QSqlQuery>
#include <QStandardPaths>
#include <QStringList>
#include <QTimeZone>
#include <QUuid>

#include <cmath>

namespace
{
constexpr int currencyIndex(const Currency currency)
{
    return static_cast<int>(currency);
}

Currency currencyFromCode(const QString& code)
{
    if (code == QStringLiteral("USD")) {
        return Currency::USD;
    }
    if (code == QStringLiteral("EUR")) {
        return Currency::EUR;
    }
    return Currency::RUB;
}

AssetType assetTypeFromInt(const int value)
{
    if (value == 1) {
        return AssetType::Crypto;
    }
    if (value == 2) {
        return AssetType::Investment;
    }
    return AssetType::Fiat;
}

bool isTransferCategory(const QString& categoryId)
{
    return categoryId == QStringLiteral("transfer-in") ||
           categoryId == QStringLiteral("transfer-out");
}

struct TransferComponentIds
{
    QString outgoing;
    QString incoming;
    bool valid = false;
};

TransferComponentIds transferComponentIds(
    const QString& id,
    const QString& categoryId
    )
{
    QString transferId;
    if (categoryId == QStringLiteral("transfer-out") &&
        id.endsWith(QStringLiteral("-out"))) {
        transferId = id.left(id.size() - 4);
    } else if (categoryId == QStringLiteral("transfer-in") &&
               id.endsWith(QStringLiteral("-in"))) {
        transferId = id.left(id.size() - 3);
    }

    if (transferId.isEmpty()) {
        return {};
    }

    return {
        transferId + QStringLiteral("-out"),
        transferId + QStringLiteral("-in"),
        true
    };
}

void prepareTransactionInsert(QSqlQuery& query)
{
    query.prepare(QStringLiteral(
        "INSERT INTO transactions(id, account_id, category_id, type, "
        "amount_minor, occurred_at, description, project_id, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"));
}

bool insertTransactionRow(
    QSqlQuery& query,
    const Transaction& transaction,
    const qint64 createdAt
    )
{
    query.bindValue(0, transaction.id());
    query.bindValue(1, transaction.accountId());
    query.bindValue(2, transaction.categoryId());
    query.bindValue(3, transaction.type() == TransactionType::Income ? 0 : 1);
    query.bindValue(4, transaction.money().minorUnits());
    query.bindValue(5, transaction.date().toMSecsSinceEpoch());
    query.bindValue(6, transaction.description());
    if (transaction.projectId().isEmpty()) {
        query.bindValue(7, QVariant());
    } else {
        query.bindValue(7, transaction.projectId());
    }
    query.bindValue(8, createdAt);
    return query.exec();
}

bool deleteOperationRows(
    QSqlDatabase& database,
    const QString& id,
    QString& error
    )
{
    QSqlQuery lookup(database);
    lookup.prepare(QStringLiteral(
        "SELECT category_id FROM transactions WHERE id = ?"));
    lookup.addBindValue(id);
    if (!lookup.exec()) {
        error = lookup.lastError().text();
        return false;
    }
    if (!lookup.next()) {
        error = QStringLiteral("Transaction was not found");
        return false;
    }

    const QString categoryId = lookup.value(0).toString();
    lookup.finish();
    const TransferComponentIds componentIds = transferComponentIds(id, categoryId);

    QSqlQuery deletion(database);
    if (isTransferCategory(categoryId) && componentIds.valid) {
        deletion.prepare(QStringLiteral(
            "DELETE FROM transactions "
            "WHERE (id = ? AND category_id = 'transfer-out') "
            "   OR (id = ? AND category_id = 'transfer-in')"));
        deletion.addBindValue(componentIds.outgoing);
        deletion.addBindValue(componentIds.incoming);
    } else {
        deletion.prepare(QStringLiteral(
            "DELETE FROM transactions WHERE id = ?"));
        deletion.addBindValue(id);
    }

    if (!deletion.exec() || deletion.numRowsAffected() < 1) {
        error = deletion.lastError().isValid()
            ? deletion.lastError().text()
            : QStringLiteral("Transaction was not found");
        return false;
    }
    return true;
}
}

FinanceRepository::FinanceRepository(const QString& databasePath)
    : connectionName_(QUuid::createUuid().toString(QUuid::WithoutBraces))
    , database_(QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), connectionName_))
{
    const QString resolvedDatabasePath = databasePath.isEmpty()
        ? QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
            + QStringLiteral("/moneytracker.sqlite3")
        : databasePath;
    const QString directory = QFileInfo(resolvedDatabasePath).absolutePath();

    if (!QDir().mkpath(directory)) {
        setLastError(QStringLiteral("Cannot create application data directory"));
        return;
    }

    database_.setDatabaseName(resolvedDatabasePath);
    if (!database_.open()) {
        setLastError(database_.lastError().text());
        return;
    }

    QSqlQuery pragma(database_);
    if (!pragma.exec(QStringLiteral("PRAGMA foreign_keys = ON"))) {
        setLastError(pragma.lastError().text());
        database_.close();
        return;
    }

    if (!initializeSchema() || !migrateLegacySchema() || !seedDefaults()) {
        database_.close();
    }
}

FinanceRepository::~FinanceRepository()
{
    database_.close();
    database_ = QSqlDatabase();
    QSqlDatabase::removeDatabase(connectionName_);
}

bool FinanceRepository::isOpen() const { return database_.isOpen(); }
QString FinanceRepository::lastError() const { return lastError_; }

QVector<Transaction> FinanceRepository::loadTransactions()
{
    QVector<Transaction> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT t.id, t.account_id, t.category_id, t.amount_minor, "
            "t.type, t.occurred_at, t.description, a.currency, t.project_id "
            "FROM transactions t JOIN accounts a ON a.id = t.account_id "
            "ORDER BY t.occurred_at DESC, t.created_at DESC"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(Transaction(
            query.value(0).toString(), query.value(1).toString(),
            query.value(2).toString(),
            Money(query.value(3).toLongLong(),
                  currencyFromCode(query.value(7).toString())),
            query.value(4).toInt() == 0
                ? TransactionType::Income : TransactionType::Expense,
            QDateTime::fromMSecsSinceEpoch(
                query.value(5).toLongLong(), QTimeZone::UTC),
            query.value(6).toString(),
            query.value(8).toString()));
    }
    return result;
}

QVector<Project> FinanceRepository::loadProjects()
{
    QVector<Project> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id, name FROM projects "
            "WHERE is_archived = 0 "
            "ORDER BY created_at, name COLLATE NOCASE"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(Project(
            query.value(0).toString(),
            query.value(1).toString()));
    }
    return result;
}

QVector<Budget> FinanceRepository::loadBudgets()
{
    QVector<Budget> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id, name, currency, default_limit_minor, "
            "all_accounts, all_categories, starts_on "
            "FROM budgets WHERE is_archived = 0 "
            "ORDER BY created_at, name COLLATE NOCASE"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        const QString id = query.value(0).toString();
        QStringList accountIds;
        QSqlQuery accounts(database_);
        accounts.prepare(QStringLiteral(
            "SELECT account_id FROM budget_accounts "
            "WHERE budget_id = ? ORDER BY account_id"));
        accounts.addBindValue(id);
        if (!accounts.exec()) {
            setLastError(accounts.lastError().text());
            return {};
        }
        while (accounts.next()) {
            accountIds.append(accounts.value(0).toString());
        }

        QVector<BudgetCategoryLimit> categoryLimits;
        QSqlQuery categories(database_);
        categories.prepare(QStringLiteral(
            "SELECT category_id, limit_minor FROM budget_category_limits "
            "WHERE budget_id = ? ORDER BY category_id"));
        categories.addBindValue(id);
        if (!categories.exec()) {
            setLastError(categories.lastError().text());
            return {};
        }
        while (categories.next()) {
            categoryLimits.append({
                categories.value(0).toString(),
                categories.value(1).toLongLong()});
        }

        result.append(Budget(
            id,
            query.value(1).toString(),
            currencyFromCode(query.value(2).toString()),
            query.value(3).toLongLong(),
            query.value(4).toBool(),
            query.value(5).toBool(),
            accountIds,
            categoryLimits,
            QDate::fromString(query.value(6).toString(), Qt::ISODate)));
    }
    return result;
}

qint64 FinanceRepository::loadBudgetLimit(
    const QString& budgetId,
    const QDate& month,
    const qint64 fallback
    )
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "SELECT limit_minor FROM budget_months "
        "WHERE budget_id = ? AND month = ?"));
    query.addBindValue(budgetId);
    query.addBindValue(QDate(month.year(), month.month(), 1).toString(Qt::ISODate));
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return fallback;
    }
    return query.next() ? query.value(0).toLongLong() : fallback;
}

namespace
{
bool replaceBudgetScopes(QSqlDatabase& database, const Budget& budget)
{
    QSqlQuery deleteAccounts(database);
    deleteAccounts.prepare(QStringLiteral(
        "DELETE FROM budget_accounts WHERE budget_id = ?"));
    deleteAccounts.addBindValue(budget.id());
    if (!deleteAccounts.exec()) {
        return false;
    }

    QSqlQuery deleteCategories(database);
    deleteCategories.prepare(QStringLiteral(
        "DELETE FROM budget_category_limits WHERE budget_id = ?"));
    deleteCategories.addBindValue(budget.id());
    if (!deleteCategories.exec()) {
        return false;
    }

    QSqlQuery account(database);
    account.prepare(QStringLiteral(
        "INSERT INTO budget_accounts(budget_id, account_id) VALUES(?, ?)"));
    for (const QString& accountId : budget.accountIds()) {
        account.bindValue(0, budget.id());
        account.bindValue(1, accountId);
        if (!account.exec()) {
            return false;
        }
    }

    QSqlQuery category(database);
    category.prepare(QStringLiteral(
        "INSERT INTO budget_category_limits(budget_id, category_id, limit_minor) "
        "VALUES(?, ?, ?)"));
    for (const BudgetCategoryLimit& limit : budget.categoryLimits()) {
        category.bindValue(0, budget.id());
        category.bindValue(1, limit.categoryId);
        category.bindValue(2, limit.limitMinor);
        if (!category.exec()) {
            return false;
        }
    }
    return true;
}

bool saveBudgetMonth(
    QSqlDatabase& database,
    const QString& budgetId,
    const QDate& month,
    const qint64 limitMinor
    )
{
    QSqlQuery query(database);
    query.prepare(QStringLiteral(
        "INSERT INTO budget_months(budget_id, month, limit_minor) "
        "VALUES(?, ?, ?) ON CONFLICT(budget_id, month) DO UPDATE SET "
        "limit_minor = excluded.limit_minor"));
    query.addBindValue(budgetId);
    query.addBindValue(QDate(month.year(), month.month(), 1).toString(Qt::ISODate));
    query.addBindValue(limitMinor);
    return query.exec();
}
}

bool FinanceRepository::insertBudget(const Budget& budget, const QDate& month)
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }
    const qint64 now = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO budgets(id, name, currency, default_limit_minor, "
        "all_accounts, all_categories, starts_on, is_archived, created_at, updated_at) "
        "VALUES(?, ?, ?, ?, ?, ?, ?, 0, ?, ?)"));
    query.addBindValue(budget.id());
    query.addBindValue(budget.name());
    query.addBindValue(currencyCode(budget.currency()));
    query.addBindValue(budget.defaultLimitMinor());
    query.addBindValue(budget.allAccounts() ? 1 : 0);
    query.addBindValue(budget.allCategories() ? 1 : 0);
    query.addBindValue(budget.startsOn().toString(Qt::ISODate));
    query.addBindValue(now);
    query.addBindValue(now);
    if (!query.exec() || !replaceBudgetScopes(database_, budget) ||
        !saveBudgetMonth(database_, budget.id(), month,
                         budget.defaultLimitMinor()) ||
        !database_.commit()) {
        setLastError(query.lastError().isValid()
            ? query.lastError().text() : database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::updateBudget(const Budget& budget, const QDate& month)
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE budgets SET name = ?, currency = ?, default_limit_minor = ?, "
        "all_accounts = ?, all_categories = ?, updated_at = ? "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(budget.name());
    query.addBindValue(currencyCode(budget.currency()));
    query.addBindValue(budget.defaultLimitMinor());
    query.addBindValue(budget.allAccounts() ? 1 : 0);
    query.addBindValue(budget.allCategories() ? 1 : 0);
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    query.addBindValue(budget.id());
    if (!query.exec() || query.numRowsAffected() != 1 ||
        !replaceBudgetScopes(database_, budget) ||
        !saveBudgetMonth(database_, budget.id(), month,
                         budget.defaultLimitMinor()) ||
        !database_.commit()) {
        setLastError(query.lastError().isValid()
            ? query.lastError().text() : database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::archiveBudget(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE budgets SET is_archived = 1, updated_at = ? "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    query.addBindValue(id);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return query.numRowsAffected() == 1;
}

bool FinanceRepository::ensureBudgetMonth(
    const QString& budgetId,
    const QDate& month,
    const qint64 limitMinor
    )
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT OR IGNORE INTO budget_months(budget_id, month, limit_minor) "
        "VALUES(?, ?, ?)"));
    query.addBindValue(budgetId);
    query.addBindValue(QDate(month.year(), month.month(), 1).toString(Qt::ISODate));
    query.addBindValue(limitMinor);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

QVector<RecurringTransaction> FinanceRepository::loadRecurringTransactions()
{
    QVector<RecurringTransaction> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id, name, account_id, category_id, type, amount_minor, "
            "       amount_currency, recurrence_type, weekday, day_of_month, "
            "       week_of_month, starts_on, generated_through "
            "FROM recurring_transactions "
            "ORDER BY created_at, name COLLATE NOCASE"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(RecurringTransaction(
            query.value(0).toString(),
            query.value(1).toString(),
            query.value(2).toString(),
            query.value(3).toString(),
            query.value(4).toInt() == 0
                ? TransactionType::Income
                : TransactionType::Expense,
            query.value(5).toLongLong(),
            currencyFromCode(query.value(6).toString()),
            static_cast<RecurrenceType>(query.value(7).toInt()),
            query.value(8).toInt(),
            query.value(9).toInt(),
            query.value(10).toInt(),
            QDate::fromString(query.value(11).toString(), Qt::ISODate),
            QDate::fromString(query.value(12).toString(), Qt::ISODate)));
    }
    return result;
}

QVector<Category> FinanceRepository::loadCategories()
{
    QVector<Category> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id, name, type FROM categories "
            "ORDER BY type, name COLLATE NOCASE"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(Category(
            query.value(0).toString(),
            query.value(1).toString(),
            query.value(2).toInt() == 0
                ? CategoryType::Income
                : CategoryType::Expense));
    }
    return result;
}

QVector<Account> FinanceRepository::loadAccounts()
{
    QVector<Account> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id, name, asset_type, account_type, currency, "
            "       initial_balance_minor, credit_limit_minor "
            "FROM accounts WHERE is_archived = 0 "
            "ORDER BY asset_type, created_at, name COLLATE NOCASE"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(Account(
            query.value(0).toString(),
            query.value(1).toString(),
            assetTypeFromInt(query.value(2).toInt()),
            static_cast<AccountType>(query.value(3).toInt()),
            currencyFromCode(query.value(4).toString()),
            query.value(5).toLongLong(),
            query.value(6).toLongLong()));
    }
    return result;
}

QVector<CryptoWallet> FinanceRepository::loadCryptoWallets()
{
    QVector<CryptoWallet> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id, address, network, symbol, decimals, balance_atomic, "
            "       balance_fetched_at, history_fetched_at "
            "FROM crypto_wallets WHERE is_archived = 0 "
            "ORDER BY created_at, symbol, address"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        const QVariant fetchedAt = query.value(6);
        result.append(CryptoWallet(
            query.value(0).toString(),
            query.value(1).toString(),
            query.value(2).toString(),
            query.value(3).toString(),
            query.value(4).toInt(),
            query.value(5).toLongLong(),
            fetchedAt.isNull()
                ? QDateTime()
                : QDateTime::fromMSecsSinceEpoch(
                      fetchedAt.toLongLong(), QTimeZone::UTC),
            query.value(7).isNull()
                ? QDateTime()
                : QDateTime::fromMSecsSinceEpoch(
                      query.value(7).toLongLong(), QTimeZone::UTC)));
    }
    return result;
}

QVector<CryptoTransaction> FinanceRepository::loadCryptoTransactions()
{
    QVector<CryptoTransaction> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT ct.wallet_id, ct.transaction_id, ct.from_address, "
            "       ct.to_address, ct.amount_atomic, ct.occurred_at "
            "FROM crypto_transactions ct "
            "JOIN crypto_wallets cw ON cw.id = ct.wallet_id "
            "WHERE cw.is_archived = 0 "
            "ORDER BY ct.occurred_at DESC, ct.transaction_id"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(CryptoTransaction(
            query.value(0).toString(),
            query.value(1).toString(),
            query.value(2).toString(),
            query.value(3).toString(),
            query.value(4).toLongLong(),
            QDateTime::fromMSecsSinceEpoch(
                query.value(5).toLongLong(), QTimeZone::UTC)));
    }
    return result;
}

QVector<InvestmentInstrument> FinanceRepository::loadInvestmentInstruments()
{
    QVector<InvestmentInstrument> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id, symbol, isin, name, type, currency, "
            "       market_code, primary_board_id "
            "FROM investment_instruments WHERE is_archived = 0 "
            "ORDER BY name COLLATE NOCASE, symbol COLLATE NOCASE"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(InvestmentInstrument(
            query.value(0).toString(),
            query.value(1).toString(),
            query.value(2).toString(),
            query.value(3).toString(),
            static_cast<InvestmentInstrumentType>(query.value(4).toInt()),
            currencyFromCode(query.value(5).toString()),
            query.value(6).toString(),
            query.value(7).toString()));
    }
    return result;
}

QVector<InvestmentPosition> FinanceRepository::loadInvestmentPositions()
{
    QVector<InvestmentPosition> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT p.id, p.account_id, p.instrument_id, "
            "       p.quantity_micros, p.average_price_micros, "
            "       p.created_at, p.updated_at "
            "FROM investment_positions p "
            "JOIN accounts a ON a.id = p.account_id "
            "JOIN investment_instruments i ON i.id = p.instrument_id "
            "WHERE p.is_archived = 0 AND a.is_archived = 0 "
            "  AND i.is_archived = 0 "
            "ORDER BY p.created_at, p.id"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(InvestmentPosition(
            query.value(0).toString(),
            query.value(1).toString(),
            query.value(2).toString(),
            query.value(3).toLongLong(),
            query.value(4).toLongLong(),
            QDateTime::fromMSecsSinceEpoch(
                query.value(5).toLongLong(), QTimeZone::UTC),
            QDateTime::fromMSecsSinceEpoch(
                query.value(6).toLongLong(), QTimeZone::UTC)));
    }
    return result;
}

QVector<InvestmentQuote> FinanceRepository::loadInvestmentQuotes()
{
    QVector<InvestmentQuote> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT q.instrument_id, q.price_micros, q.quoted_at "
            "FROM investment_quotes q "
            "JOIN investment_instruments i ON i.id = q.instrument_id "
            "WHERE i.is_archived = 0 "
            "ORDER BY q.quoted_at DESC, q.instrument_id"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.append(InvestmentQuote(
            query.value(0).toString(),
            query.value(1).toLongLong(),
            QDateTime::fromMSecsSinceEpoch(
                query.value(2).toLongLong(), QTimeZone::UTC)));
    }
    return result;
}

FinanceRepository::CryptoPriceSnapshot FinanceRepository::loadCryptoPrice(
    const QString& symbol
    ) const
{
    CryptoPriceSnapshot result;
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "SELECT price_usd_micros, fetched_at "
        "FROM crypto_prices WHERE symbol = ?"));
    query.addBindValue(symbol.trimmed().toUpper());
    if (query.exec() && query.next()) {
        const qint64 price = query.value(0).toLongLong();
        if (price > 0) {
            result.priceUsdMicros = price;
        }
        if (!query.value(1).isNull()) {
            result.fetchedAtUtc = QDateTime::fromMSecsSinceEpoch(
                query.value(1).toLongLong(), QTimeZone::UTC);
        }
    }
    return result;
}

QDateTime FinanceRepository::loadCryptoRefreshAttemptUtc() const
{
    QSqlQuery query(database_);
    if (query.exec(QStringLiteral(
            "SELECT value FROM settings "
            "WHERE key = 'crypto_refresh_attempt_utc'")) &&
        query.next()) {
        bool ok = false;
        const qint64 milliseconds = query.value(0).toString().toLongLong(&ok);
        if (ok && milliseconds > 0) {
            return QDateTime::fromMSecsSinceEpoch(
                milliseconds, QTimeZone::UTC);
        }
    }
    return {};
}

QSet<QString> FinanceRepository::loadArchivedCategoryIds()
{
    QSet<QString> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id FROM categories WHERE is_archived = 1"))) {
        setLastError(query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.insert(query.value(0).toString());
    }
    return result;
}

FinanceRepository::Summary FinanceRepository::loadSummary()
{
    Summary summary;

    QSqlQuery accounts(database_);
    if (!accounts.exec(QStringLiteral(
            "SELECT a.currency, "
            "       SUM(a.initial_balance_minor + COALESCE(t.net_amount, 0)) "
            "FROM accounts a "
            "LEFT JOIN ("
            "    SELECT account_id, "
            "           SUM(CASE "
            "                   WHEN type = 0 THEN amount_minor "
            "                   WHEN type = 1 THEN -amount_minor "
            "               END) AS net_amount "
            "    FROM transactions "
            "    GROUP BY account_id"
            ") t ON t.account_id = a.id "
            "WHERE a.is_archived = 0 "
            "GROUP BY a.currency"))) {
        setLastError(accounts.lastError().text());
        return summary;
    }

    while (accounts.next()) {
        const Currency currency = currencyFromCode(accounts.value(0).toString());
        summary.balance[currencyIndex(currency)] = accounts.value(1).toLongLong();
    }

    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT t.type, a.currency, SUM(t.amount_minor), t.category_id "
            "FROM transactions t JOIN accounts a ON a.id = t.account_id "
            "WHERE a.is_archived = 0 "
            "GROUP BY t.type, a.currency, t.category_id"))) {
        setLastError(query.lastError().text());
        return summary;
    }

    while (query.next()) {
        const QString categoryId = query.value(3).toString();
        if (categoryId == QStringLiteral("transfer-in") ||
            categoryId == QStringLiteral("transfer-out")) {
            continue;
        }
        const int type = query.value(0).toInt();
        const Currency currency = currencyFromCode(query.value(1).toString());
        auto& values = type == 0 ? summary.income : summary.expense;
        const qint64 amount = query.value(2).toLongLong();
        values[currencyIndex(currency)] += amount;
    }
    return summary;
}

bool FinanceRepository::insertTransaction(const Transaction& transaction)
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery query(database_);
    prepareTransactionInsert(query);

    if (!insertTransactionRow(
            query,
            transaction,
            QDateTime::currentDateTimeUtc().toMSecsSinceEpoch()) ||
        !database_.commit()) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::insertTransfer(
    const Transaction& outgoing,
    const Transaction& incoming
    )
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery query(database_);
    prepareTransactionInsert(query);
    const qint64 createdAt = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();

    if (!insertTransactionRow(query, outgoing, createdAt) ||
        !insertTransactionRow(query, incoming, createdAt) ||
        !database_.commit()) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::insertTransactions(
    const QVector<Transaction>& transactions
    )
{
    if (transactions.isEmpty()) {
        return true;
    }
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery query(database_);
    prepareTransactionInsert(query);
    const qint64 createdAt = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    for (const Transaction& transaction : transactions) {
        if (!insertTransactionRow(query, transaction, createdAt)) {
            setLastError(query.lastError().text());
            database_.rollback();
            return false;
        }
    }
    if (!database_.commit()) {
        setLastError(database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::updateTransaction(const Transaction& transaction)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE transactions "
        "SET account_id = ?, category_id = ?, type = ?, amount_minor = ?, "
        "    occurred_at = ?, description = ?, project_id = ? "
        "WHERE id = ?"));
    query.addBindValue(transaction.accountId());
    query.addBindValue(transaction.categoryId());
    query.addBindValue(transaction.type() == TransactionType::Income ? 0 : 1);
    query.addBindValue(transaction.money().minorUnits());
    query.addBindValue(transaction.date().toMSecsSinceEpoch());
    query.addBindValue(transaction.description());
    if (transaction.projectId().isEmpty()) {
        query.addBindValue(QVariant());
    } else {
        query.addBindValue(transaction.projectId());
    }
    query.addBindValue(transaction.id());

    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Transaction was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::replaceTransaction(
    const QString& currentId,
    const Transaction& replacement
    )
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QString error;
    QSqlQuery insertion(database_);
    prepareTransactionInsert(insertion);
    const bool succeeded =
        deleteOperationRows(database_, currentId, error) &&
        insertTransactionRow(
            insertion,
            replacement,
            QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());

    if (!succeeded || !database_.commit()) {
        if (error.isEmpty()) {
            error = insertion.lastError().isValid()
                ? insertion.lastError().text()
                : database_.lastError().text();
        }
        setLastError(error);
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::replaceTransactionWithTransfer(
    const QString& currentId,
    const Transaction& outgoing,
    const Transaction& incoming
    )
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QString error;
    QSqlQuery insertion(database_);
    prepareTransactionInsert(insertion);
    const qint64 createdAt = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    const bool succeeded =
        deleteOperationRows(database_, currentId, error) &&
        insertTransactionRow(insertion, outgoing, createdAt) &&
        insertTransactionRow(insertion, incoming, createdAt);

    if (!succeeded || !database_.commit()) {
        if (error.isEmpty()) {
            error = insertion.lastError().isValid()
                ? insertion.lastError().text()
                : database_.lastError().text();
        }
        setLastError(error);
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::deleteTransaction(const QString& id)
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QString error;
    if (!deleteOperationRows(database_, id, error) || !database_.commit()) {
        setLastError(error.isEmpty() ? database_.lastError().text() : error);
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::insertRecurringTransaction(
    const RecurringTransaction& recurring
    )
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO recurring_transactions("
        "id, name, account_id, category_id, type, amount_minor, amount_currency, "
        "recurrence_type, weekday, day_of_month, week_of_month, "
        "starts_on, generated_through, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"));
    const qint64 now = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    query.addBindValue(recurring.id());
    query.addBindValue(recurring.name().trimmed());
    query.addBindValue(recurring.accountId());
    query.addBindValue(recurring.categoryId());
    query.addBindValue(
        recurring.transactionType() == TransactionType::Income ? 0 : 1);
    query.addBindValue(recurring.amountMinor());
    query.addBindValue(currencyCode(recurring.currency()));
    query.addBindValue(static_cast<int>(recurring.recurrenceType()));
    query.addBindValue(recurring.weekday());
    query.addBindValue(recurring.dayOfMonth());
    query.addBindValue(recurring.weekOfMonth());
    query.addBindValue(recurring.startsOn().toString(Qt::ISODate));
    query.addBindValue(recurring.generatedThrough().toString(Qt::ISODate));
    query.addBindValue(now);
    query.addBindValue(now);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::updateRecurringTransaction(
    const RecurringTransaction& recurring
    )
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE recurring_transactions SET "
        "name = ?, account_id = ?, category_id = ?, type = ?, "
        "amount_minor = ?, amount_currency = ?, recurrence_type = ?, weekday = ?, "
        "day_of_month = ?, week_of_month = ?, starts_on = ?, "
        "updated_at = ? WHERE id = ?"));
    query.addBindValue(recurring.name().trimmed());
    query.addBindValue(recurring.accountId());
    query.addBindValue(recurring.categoryId());
    query.addBindValue(
        recurring.transactionType() == TransactionType::Income ? 0 : 1);
    query.addBindValue(recurring.amountMinor());
    query.addBindValue(currencyCode(recurring.currency()));
    query.addBindValue(static_cast<int>(recurring.recurrenceType()));
    query.addBindValue(recurring.weekday());
    query.addBindValue(recurring.dayOfMonth());
    query.addBindValue(recurring.weekOfMonth());
    query.addBindValue(recurring.startsOn().toString(Qt::ISODate));
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    query.addBindValue(recurring.id());
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Recurring transaction was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::deleteRecurringTransaction(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "DELETE FROM recurring_transactions WHERE id = ?"));
    query.addBindValue(id);
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Recurring transaction was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::materializeRecurringOccurrences(
    const QString& recurringId,
    const QVector<RecurringOccurrence>& occurrences,
    const QDate& generatedThrough,
    int* insertedCount
    )
{
    if (recurringId.isEmpty() || !generatedThrough.isValid()) {
        setLastError(QStringLiteral("Invalid recurring materialization range"));
        return false;
    }
    if (insertedCount) {
        *insertedCount = 0;
    }
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery occurrenceLookup(database_);
    occurrenceLookup.prepare(QStringLiteral(
        "SELECT 1 FROM recurring_transaction_occurrences "
        "WHERE recurring_id = ? AND occurrence_date = ?"));
    QSqlQuery transactionInsert(database_);
    prepareTransactionInsert(transactionInsert);
    QSqlQuery occurrenceInsert(database_);
    occurrenceInsert.prepare(QStringLiteral(
        "INSERT INTO recurring_transaction_occurrences("
        "recurring_id, occurrence_date, transaction_id) "
        "VALUES (?, ?, ?)"));
    const qint64 createdAt = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    int inserted = 0;

    for (const RecurringOccurrence& occurrence : occurrences) {
        const QString date = occurrence.date.toString(Qt::ISODate);
        occurrenceLookup.bindValue(0, recurringId);
        occurrenceLookup.bindValue(1, date);
        if (!occurrenceLookup.exec()) {
            setLastError(occurrenceLookup.lastError().text());
            database_.rollback();
            return false;
        }
        const bool alreadyCreated = occurrenceLookup.next();
        occurrenceLookup.finish();
        if (alreadyCreated) {
            continue;
        }

        if (!insertTransactionRow(
                transactionInsert, occurrence.transaction, createdAt)) {
            setLastError(transactionInsert.lastError().text());
            database_.rollback();
            return false;
        }
        occurrenceInsert.bindValue(0, recurringId);
        occurrenceInsert.bindValue(1, date);
        occurrenceInsert.bindValue(2, occurrence.transaction.id());
        if (!occurrenceInsert.exec()) {
            setLastError(occurrenceInsert.lastError().text());
            database_.rollback();
            return false;
        }
        ++inserted;
    }

    QSqlQuery progress(database_);
    progress.prepare(QStringLiteral(
        "UPDATE recurring_transactions SET generated_through = CASE "
        "WHEN generated_through < ? THEN ? ELSE generated_through END, "
        "updated_at = ? WHERE id = ?"));
    const QString through = generatedThrough.toString(Qt::ISODate);
    progress.addBindValue(through);
    progress.addBindValue(through);
    progress.addBindValue(createdAt);
    progress.addBindValue(recurringId);
    if (!progress.exec() || progress.numRowsAffected() != 1 ||
        !database_.commit()) {
        setLastError(progress.lastError().isValid()
                         ? progress.lastError().text()
                         : database_.lastError().text());
        database_.rollback();
        return false;
    }
    if (insertedCount) {
        *insertedCount = inserted;
    }
    return true;
}

bool FinanceRepository::insertCategory(const Category& category)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO categories(id, name, type, is_system, created_at) "
        "VALUES (?, ?, ?, 0, ?)"));
    query.addBindValue(category.id());
    query.addBindValue(category.name());
    query.addBindValue(category.type() == CategoryType::Income ? 0 : 1);
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());

    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::insertProject(const Project& project)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO projects(id, name, is_archived, created_at, updated_at) "
        "VALUES (?, ?, 0, ?, ?)"));
    const qint64 now = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    query.addBindValue(project.id());
    query.addBindValue(project.name().trimmed());
    query.addBindValue(now);
    query.addBindValue(now);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::updateProject(const Project& project)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE projects SET name = ?, updated_at = ? "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(project.name().trimmed());
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    query.addBindValue(project.id());
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Project was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::archiveProject(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE projects SET is_archived = 1, updated_at = ? "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    query.addBindValue(id);
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Project was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::insertAccount(const Account& account)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO accounts(id, name, asset_type, account_type, currency, "
        "initial_balance_minor, credit_limit_minor, is_archived, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)"));
    query.addBindValue(account.id());
    query.addBindValue(account.name());
    query.addBindValue(static_cast<int>(account.assetType()));
    query.addBindValue(static_cast<int>(account.type()));
    query.addBindValue(currencyCode(account.currency()));
    query.addBindValue(account.initialBalanceMinor());
    query.addBindValue(account.creditLimitMinor());
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());

    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::updateAccount(const Account& account)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE accounts "
        "SET name = ?, asset_type = ?, account_type = ?, currency = ?, "
        "    initial_balance_minor = ?, credit_limit_minor = ? "
        "WHERE id = ? AND is_archived = 0 "
        "  AND (currency = ? OR NOT EXISTS ("
        "      SELECT 1 FROM transactions WHERE account_id = ?"
        "  ))"));
    query.addBindValue(account.name());
    query.addBindValue(static_cast<int>(account.assetType()));
    query.addBindValue(static_cast<int>(account.type()));
    query.addBindValue(currencyCode(account.currency()));
    query.addBindValue(account.initialBalanceMinor());
    query.addBindValue(account.creditLimitMinor());
    query.addBindValue(account.id());
    query.addBindValue(currencyCode(account.currency()));
    query.addBindValue(account.id());

    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral(
                               "Account was not found or its currency cannot be changed"));
        return false;
    }
    return true;
}

bool FinanceRepository::deleteAccount(const QString& id)
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery recurring(database_);
    recurring.prepare(QStringLiteral(
        "DELETE FROM recurring_transactions WHERE account_id = ?"));
    recurring.addBindValue(id);
    if (!recurring.exec()) {
        setLastError(recurring.lastError().text());
        database_.rollback();
        return false;
    }

    QSqlQuery lookup(database_);
    lookup.prepare(QStringLiteral(
        "SELECT id FROM transactions WHERE account_id = ?"));
    lookup.addBindValue(id);
    if (!lookup.exec()) {
        setLastError(lookup.lastError().text());
        database_.rollback();
        return false;
    }

    QStringList transactionIds;
    while (lookup.next()) {
        transactionIds.append(lookup.value(0).toString());
    }
    lookup.finish();

    QString error;
    QSqlQuery existence(database_);
    existence.prepare(QStringLiteral(
        "SELECT 1 FROM transactions WHERE id = ?"));
    for (const QString& transactionId : transactionIds) {
        existence.bindValue(0, transactionId);
        if (!existence.exec()) {
            setLastError(existence.lastError().text());
            database_.rollback();
            return false;
        }
        const bool stillExists = existence.next();
        existence.finish();
        if (!stillExists) {
            continue;
        }
        if (!deleteOperationRows(database_, transactionId, error)) {
            setLastError(error);
            database_.rollback();
            return false;
        }
    }

    QSqlQuery positions(database_);
    positions.prepare(QStringLiteral(
        "UPDATE investment_positions "
        "SET is_archived = 1, updated_at = ? "
        "WHERE account_id = ? AND is_archived = 0"));
    positions.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    positions.addBindValue(id);
    if (!positions.exec()) {
        setLastError(positions.lastError().text());
        database_.rollback();
        return false;
    }

    QSqlQuery account(database_);
    account.prepare(QStringLiteral(
        "UPDATE accounts SET is_archived = 1 "
        "WHERE id = ? AND is_archived = 0"));
    account.addBindValue(id);
    if (!account.exec() || account.numRowsAffected() != 1 ||
        !database_.commit()) {
        setLastError(account.lastError().isValid()
                         ? account.lastError().text()
                         : database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::insertCryptoWallet(const CryptoWallet& wallet)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO crypto_wallets("
        "id, address, network, symbol, decimals, balance_atomic, "
        "balance_fetched_at, is_archived, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)"));
    query.addBindValue(wallet.id());
    query.addBindValue(wallet.address());
    query.addBindValue(wallet.network());
    query.addBindValue(wallet.symbol());
    query.addBindValue(wallet.decimals());
    query.addBindValue(wallet.balanceAtomic());
    if (wallet.balanceFetchedAtUtc().isValid()) {
        query.addBindValue(
            wallet.balanceFetchedAtUtc().toUTC().toMSecsSinceEpoch());
    } else {
        query.addBindValue(QVariant());
    }
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());

    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::updateCryptoWalletBalance(
    const QString& id,
    const qint64 balanceAtomic,
    const QDateTime& fetchedAtUtc
    )
{
    if (balanceAtomic < 0 || !fetchedAtUtc.isValid()) {
        setLastError(QStringLiteral("Invalid crypto-wallet balance snapshot"));
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE crypto_wallets "
        "SET balance_atomic = ?, balance_fetched_at = ? "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(balanceAtomic);
    query.addBindValue(fetchedAtUtc.toUTC().toMSecsSinceEpoch());
    query.addBindValue(id);
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Crypto wallet was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::deleteCryptoWallet(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE crypto_wallets SET is_archived = 1 "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(id);
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Crypto wallet was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::replaceCryptoTransactions(
    const QString& walletId,
    const QVector<CryptoTransaction>& transactions,
    const QDateTime& fetchedAtUtc
    )
{
    if (walletId.isEmpty() || !fetchedAtUtc.isValid()) {
        setLastError(QStringLiteral("Invalid crypto transaction snapshot"));
        return false;
    }
    for (const CryptoTransaction& transaction : transactions) {
        if (transaction.walletId() != walletId ||
            transaction.transactionId().isEmpty() ||
            transaction.fromAddress().isEmpty() ||
            transaction.toAddress().isEmpty() ||
            transaction.amountAtomic() <= 0 ||
            !transaction.occurredAtUtc().isValid()) {
            setLastError(QStringLiteral("Invalid crypto transaction"));
            return false;
        }
    }

    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery deletion(database_);
    deletion.prepare(QStringLiteral(
        "DELETE FROM crypto_transactions WHERE wallet_id = ?"));
    deletion.addBindValue(walletId);
    if (!deletion.exec()) {
        setLastError(deletion.lastError().text());
        database_.rollback();
        return false;
    }

    QSqlQuery insertion(database_);
    insertion.prepare(QStringLiteral(
        "INSERT INTO crypto_transactions("
        "wallet_id, transaction_id, from_address, to_address, "
        "amount_atomic, occurred_at) VALUES (?, ?, ?, ?, ?, ?)"));
    for (const CryptoTransaction& transaction : transactions) {
        insertion.bindValue(0, transaction.walletId());
        insertion.bindValue(1, transaction.transactionId());
        insertion.bindValue(2, transaction.fromAddress());
        insertion.bindValue(3, transaction.toAddress());
        insertion.bindValue(4, transaction.amountAtomic());
        insertion.bindValue(
            5,
            transaction.occurredAtUtc().toUTC().toMSecsSinceEpoch());
        if (!insertion.exec()) {
            setLastError(insertion.lastError().text());
            database_.rollback();
            return false;
        }
    }

    QSqlQuery wallet(database_);
    wallet.prepare(QStringLiteral(
        "UPDATE crypto_wallets SET history_fetched_at = ? "
        "WHERE id = ? AND is_archived = 0"));
    wallet.addBindValue(fetchedAtUtc.toUTC().toMSecsSinceEpoch());
    wallet.addBindValue(walletId);
    if (!wallet.exec() || wallet.numRowsAffected() != 1 ||
        !database_.commit()) {
        setLastError(wallet.lastError().isValid()
                         ? wallet.lastError().text()
                         : database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

bool FinanceRepository::saveCryptoPrice(
    const QString& symbol,
    const qint64 priceUsdMicros,
    const QDateTime& fetchedAtUtc
    )
{
    const QString normalizedSymbol = symbol.trimmed().toUpper();
    if ((normalizedSymbol != QStringLiteral("USDT") &&
         normalizedSymbol != QStringLiteral("BTC") &&
         normalizedSymbol != QStringLiteral("ETH")) ||
        priceUsdMicros <= 0 || !fetchedAtUtc.isValid()) {
        setLastError(QStringLiteral("Invalid crypto price snapshot"));
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO crypto_prices(symbol, price_usd_micros, fetched_at) "
        "VALUES(?, ?, ?) "
        "ON CONFLICT(symbol) DO UPDATE SET "
        "price_usd_micros = excluded.price_usd_micros, "
        "fetched_at = excluded.fetched_at"));
    query.addBindValue(normalizedSymbol);
    query.addBindValue(priceUsdMicros);
    query.addBindValue(fetchedAtUtc.toUTC().toMSecsSinceEpoch());
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::saveCryptoRefreshAttemptUtc(
    const QDateTime& attemptedAtUtc
    )
{
    if (!attemptedAtUtc.isValid()) {
        setLastError(QStringLiteral("Invalid crypto refresh timestamp"));
        return false;
    }
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO settings(key, value) "
        "VALUES('crypto_refresh_attempt_utc', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value"));
    query.addBindValue(QString::number(
        attemptedAtUtc.toUTC().toMSecsSinceEpoch()));
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::insertInvestmentInstrument(
    const InvestmentInstrument& instrument
    )
{
    const QString id = instrument.id().trimmed();
    const QString symbol = instrument.symbol().trimmed().toUpper();
    const QString isin = instrument.isin().trimmed().toUpper();
    const QString name = instrument.name().trimmed();
    const QString marketCode = instrument.marketCode().trimmed().toUpper();
    const QString primaryBoardId =
        instrument.primaryBoardId().trimmed().toUpper();
    const int type = static_cast<int>(instrument.type());
    if (id.isEmpty() || symbol.isEmpty() || name.isEmpty() ||
        type < static_cast<int>(InvestmentInstrumentType::Stock) ||
        type > static_cast<int>(InvestmentInstrumentType::Other)) {
        setLastError(QStringLiteral("Invalid investment instrument"));
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO investment_instruments("
        "id, symbol, isin, name, type, currency, market_code, "
        "primary_board_id, is_archived, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)"));
    query.addBindValue(id);
    query.addBindValue(symbol);
    query.addBindValue(isin);
    query.addBindValue(name);
    query.addBindValue(type);
    query.addBindValue(currencyCode(instrument.currency()));
    query.addBindValue(marketCode);
    query.addBindValue(primaryBoardId);
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::updateInvestmentInstrument(
    const InvestmentInstrument& instrument
    )
{
    const QString symbol = instrument.symbol().trimmed().toUpper();
    const QString isin = instrument.isin().trimmed().toUpper();
    const QString name = instrument.name().trimmed();
    const QString marketCode = instrument.marketCode().trimmed().toUpper();
    const QString primaryBoardId =
        instrument.primaryBoardId().trimmed().toUpper();
    const int type = static_cast<int>(instrument.type());
    if (instrument.id().trimmed().isEmpty() || symbol.isEmpty() ||
        name.isEmpty() ||
        type < static_cast<int>(InvestmentInstrumentType::Stock) ||
        type > static_cast<int>(InvestmentInstrumentType::Other)) {
        setLastError(QStringLiteral("Invalid investment instrument"));
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE investment_instruments "
        "SET symbol = ?, isin = ?, name = ?, type = ?, currency = ?, "
        "    market_code = ?, primary_board_id = ? "
        "WHERE id = ? AND is_archived = 0 "
        "  AND (currency = ? OR ("
        "      NOT EXISTS (SELECT 1 FROM investment_positions "
        "          WHERE instrument_id = ? AND is_archived = 0) "
        "      AND NOT EXISTS (SELECT 1 FROM investment_quotes "
        "          WHERE instrument_id = ?)))"));
    query.addBindValue(symbol);
    query.addBindValue(isin);
    query.addBindValue(name);
    query.addBindValue(type);
    query.addBindValue(currencyCode(instrument.currency()));
    query.addBindValue(marketCode);
    query.addBindValue(primaryBoardId);
    query.addBindValue(instrument.id());
    query.addBindValue(currencyCode(instrument.currency()));
    query.addBindValue(instrument.id());
    query.addBindValue(instrument.id());
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral(
                               "Investment instrument was not found or its currency cannot be changed"));
        return false;
    }
    return true;
}

bool FinanceRepository::archiveInvestmentInstrument(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE investment_instruments SET is_archived = 1 "
        "WHERE id = ? AND is_archived = 0 "
        "  AND NOT EXISTS ("
        "      SELECT 1 FROM investment_positions "
        "      WHERE instrument_id = ? AND is_archived = 0)"));
    query.addBindValue(id);
    query.addBindValue(id);
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral(
                               "Investment instrument was not found or has positions"));
        return false;
    }
    return true;
}

bool FinanceRepository::insertInvestmentPosition(
    const InvestmentPosition& position
    )
{
    if (position.id().trimmed().isEmpty() ||
        position.accountId().trimmed().isEmpty() ||
        position.instrumentId().trimmed().isEmpty() ||
        position.quantityMicros() <= 0 ||
        position.averagePriceMicros() < 0) {
        setLastError(QStringLiteral("Invalid investment position"));
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO investment_positions("
        "id, account_id, instrument_id, quantity_micros, "
        "average_price_micros, is_archived, created_at, updated_at) "
        "SELECT ?, ?, ?, ?, ?, 0, ?, ? "
        "WHERE EXISTS ("
        "    SELECT 1 FROM accounts "
        "    WHERE id = ? AND asset_type = 2 AND is_archived = 0) "
        "AND EXISTS ("
        "    SELECT 1 FROM investment_instruments "
        "    WHERE id = ? AND is_archived = 0)"));
    const qint64 now = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    query.addBindValue(position.id());
    query.addBindValue(position.accountId());
    query.addBindValue(position.instrumentId());
    query.addBindValue(position.quantityMicros());
    query.addBindValue(position.averagePriceMicros());
    query.addBindValue(now);
    query.addBindValue(now);
    query.addBindValue(position.accountId());
    query.addBindValue(position.instrumentId());
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral(
                               "Investment account or instrument was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::updateInvestmentPosition(
    const InvestmentPosition& position
    )
{
    if (position.id().trimmed().isEmpty() ||
        position.accountId().trimmed().isEmpty() ||
        position.instrumentId().trimmed().isEmpty() ||
        position.quantityMicros() <= 0 ||
        position.averagePriceMicros() < 0) {
        setLastError(QStringLiteral("Invalid investment position"));
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE investment_positions "
        "SET account_id = ?, instrument_id = ?, quantity_micros = ?, "
        "    average_price_micros = ?, updated_at = ? "
        "WHERE id = ? AND is_archived = 0 "
        "  AND EXISTS (SELECT 1 FROM accounts "
        "      WHERE id = ? AND asset_type = 2 AND is_archived = 0) "
        "  AND EXISTS (SELECT 1 FROM investment_instruments "
        "      WHERE id = ? AND is_archived = 0)"));
    query.addBindValue(position.accountId());
    query.addBindValue(position.instrumentId());
    query.addBindValue(position.quantityMicros());
    query.addBindValue(position.averagePriceMicros());
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    query.addBindValue(position.id());
    query.addBindValue(position.accountId());
    query.addBindValue(position.instrumentId());
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral(
                               "Investment position, account or instrument was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::deleteInvestmentPosition(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "DELETE FROM investment_positions WHERE id = ?"));
    query.addBindValue(id);
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Investment position was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::archiveInvestmentPosition(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE investment_positions SET is_archived = 1, updated_at = ? "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    query.addBindValue(id);
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Investment position was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::saveInvestmentQuote(const InvestmentQuote& quote)
{
    if (quote.instrumentId().trimmed().isEmpty() ||
        quote.priceMicros() <= 0 || !quote.quotedAtUtc().isValid()) {
        setLastError(QStringLiteral("Invalid investment quote"));
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO investment_quotes(instrument_id, price_micros, quoted_at) "
        "SELECT ?, ?, ? WHERE EXISTS ("
        "    SELECT 1 FROM investment_instruments "
        "    WHERE id = ? AND is_archived = 0) "
        "ON CONFLICT(instrument_id) DO UPDATE SET "
        "price_micros = excluded.price_micros, "
        "quoted_at = excluded.quoted_at "
        "WHERE excluded.quoted_at >= investment_quotes.quoted_at"));
    query.addBindValue(quote.instrumentId());
    query.addBindValue(quote.priceMicros());
    query.addBindValue(
        quote.quotedAtUtc().toUTC().toMSecsSinceEpoch());
    query.addBindValue(quote.instrumentId());
    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral(
                               "Investment instrument was not found or quote is stale"));
        return false;
    }
    return true;
}

bool FinanceRepository::updateCategoryName(
    const QString& id,
    const QString& name
    )
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE categories SET name = ? "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(name);
    query.addBindValue(id);

    if (!query.exec() || query.numRowsAffected() != 1) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : QStringLiteral("Category was not found"));
        return false;
    }
    return true;
}

bool FinanceRepository::archiveCategory(const QString& id)
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery recurring(database_);
    recurring.prepare(QStringLiteral(
        "DELETE FROM recurring_transactions WHERE category_id = ?"));
    recurring.addBindValue(id);
    if (!recurring.exec()) {
        setLastError(recurring.lastError().text());
        database_.rollback();
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "UPDATE categories SET is_archived = 1 "
        "WHERE id = ? AND is_archived = 0"));
    query.addBindValue(id);

    if (!query.exec() || query.numRowsAffected() != 1 ||
        !database_.commit()) {
        setLastError(query.lastError().isValid()
                         ? query.lastError().text()
                         : database_.lastError().isValid()
                           ? database_.lastError().text()
                           : QStringLiteral("Category was not found"));
        database_.rollback();
        return false;
    }
    return true;
}

QString FinanceRepository::loadAppCurrency() const
{
    QSqlQuery query(database_);
    if (query.exec(QStringLiteral(
            "SELECT value FROM settings WHERE key = 'app_currency'")) &&
        query.next()) {
        return query.value(0).toString();
    }
    return QStringLiteral("RUB");
}

bool FinanceRepository::saveAppCurrency(const QString& currency)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO settings(key, value) VALUES('app_currency', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value"));
    query.addBindValue(currency);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

QString FinanceRepository::loadSelectedAsset() const
{
    QSqlQuery query(database_);
    if (query.exec(QStringLiteral(
            "SELECT value FROM settings WHERE key = 'selected_asset'")) &&
        query.next()) {
        return query.value(0).toString();
    }
    return QStringLiteral("fiat");
}

bool FinanceRepository::saveSelectedAsset(const QString& asset)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO settings(key, value) VALUES('selected_asset', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value"));
    query.addBindValue(asset);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

QString FinanceRepository::loadUiLanguage() const
{
    QSqlQuery query(database_);
    if (query.exec(QStringLiteral(
            "SELECT value FROM settings WHERE key = 'ui_language'")) &&
        query.next()) {
        return query.value(0).toString();
    }
    return QStringLiteral("ru");
}

bool FinanceRepository::saveUiLanguage(const QString& language)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO settings(key, value) VALUES('ui_language', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value"));
    query.addBindValue(language);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::loadAutomaticCurrencyRates() const
{
    QSqlQuery query(database_);
    if (query.exec(QStringLiteral(
            "SELECT value FROM settings "
            "WHERE key = 'automatic_currency_rates'")) &&
        query.next()) {
        return query.value(0).toString() != QStringLiteral("0");
    }
    return true;
}

double FinanceRepository::loadManualUsdToRubRate() const
{
    QSqlQuery query(database_);
    if (query.exec(QStringLiteral(
            "SELECT value FROM settings "
            "WHERE key = 'manual_usd_to_rub_rate'")) &&
        query.next()) {
        bool valid = false;
        const double value = query.value(0).toString().toDouble(&valid);
        if (valid && std::isfinite(value) && value > 0.0) {
            return value;
        }
    }
    return 90.909090909;
}

double FinanceRepository::loadManualRubToRubRate() const
{
    QSqlQuery query(database_);
    if (query.exec(QStringLiteral(
            "SELECT value FROM settings "
            "WHERE key = 'manual_rub_to_rub_rate'")) &&
        query.next()) {
        bool valid = false;
        const double value = query.value(0).toString().toDouble(&valid);
        if (valid && std::isfinite(value) && value > 0.0) {
            return value;
        }
    }
    return 1.0;
}

double FinanceRepository::loadManualEurToRubRate() const
{
    QSqlQuery query(database_);
    if (query.exec(QStringLiteral(
            "SELECT value FROM settings "
            "WHERE key = 'manual_eur_to_rub_rate'")) &&
        query.next()) {
        bool valid = false;
        const double value = query.value(0).toString().toDouble(&valid);
        if (valid && std::isfinite(value) && value > 0.0) {
            return value;
        }
    }
    return 106.363636364;
}

bool FinanceRepository::saveAutomaticCurrencyRates(const bool enabled)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO settings(key, value) "
        "VALUES('automatic_currency_rates', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value"));
    query.addBindValue(enabled ? QStringLiteral("1") : QStringLiteral("0"));
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::saveManualCurrencyRates(
    const double rublesPerRub,
    const double rublesPerUsd,
    const double rublesPerEur
    )
{
    if (!std::isfinite(rublesPerRub) || rublesPerRub <= 0.0 ||
        !std::isfinite(rublesPerUsd) || rublesPerUsd <= 0.0 ||
        !std::isfinite(rublesPerEur) || rublesPerEur <= 0.0) {
        setLastError(QStringLiteral("Currency rates must be positive numbers"));
        return false;
    }
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO settings(key, value) VALUES(?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value"));
    const auto saveRate = [&query](const QString& key, const double value)
    {
        query.bindValue(0, key);
        query.bindValue(1, QString::number(value, 'g', 15));
        return query.exec();
    };
    if (!saveRate(QStringLiteral("manual_rub_to_rub_rate"), rublesPerRub) ||
        !saveRate(QStringLiteral("manual_usd_to_rub_rate"), rublesPerUsd) ||
        !saveRate(QStringLiteral("manual_eur_to_rub_rate"), rublesPerEur)) {
        setLastError(query.lastError().text());
        database_.rollback();
        return false;
    }
    if (!database_.commit()) {
        setLastError(database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

QVector<FinanceRepository::BankCsvProfileRecord>
FinanceRepository::loadBankCsvProfiles()
{
    QVector<BankCsvProfileRecord> result;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id, name, configuration_json "
            "FROM bank_csv_profiles ORDER BY name COLLATE NOCASE, id"))) {
        setLastError(query.lastError().text());
        return result;
    }
    while (query.next()) {
        result.append({
            query.value(0).toString(),
            query.value(1).toString(),
            query.value(2).toString()
        });
    }
    return result;
}

bool FinanceRepository::saveBankCsvProfile(
    const QString& id,
    const QString& name,
    const QString& configurationJson
    )
{
    if (id.trimmed().isEmpty() || name.trimmed().isEmpty() ||
        configurationJson.trimmed().isEmpty()) {
        setLastError(QStringLiteral("Invalid bank CSV profile"));
        return false;
    }
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO bank_csv_profiles("
        "id, name, configuration_json, created_at, updated_at) "
        "VALUES(?, ?, ?, ?, ?) "
        "ON CONFLICT(id) DO UPDATE SET "
        "name = excluded.name, "
        "configuration_json = excluded.configuration_json, "
        "updated_at = excluded.updated_at"));
    const qint64 now = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    query.addBindValue(id);
    query.addBindValue(name.trimmed());
    query.addBindValue(configurationJson);
    query.addBindValue(now);
    query.addBindValue(now);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::deleteBankCsvProfile(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "DELETE FROM bank_csv_profiles WHERE id = ?"));
    query.addBindValue(id);
    if (!query.exec()) {
        setLastError(query.lastError().text());
        return false;
    }
    return query.numRowsAffected() > 0;
}

bool FinanceRepository::initializeSchema()
{
    const QStringList statements{
        QStringLiteral("CREATE TABLE IF NOT EXISTS capital_snapshots ("
                       "snapshot_date TEXT PRIMARY KEY CHECK(length(snapshot_date) = 10), "
                       "currency TEXT NOT NULL CHECK(currency IN ('RUB','USD','EUR')), "
                       "total_minor INTEGER NOT NULL, updated_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS financial_goals ("
                       "id TEXT PRIMARY KEY, name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 80), "
                       "currency TEXT NOT NULL CHECK(currency IN ('RUB','USD','EUR')), "
                       "target_minor INTEGER NOT NULL CHECK(target_minor > 0), "
                       "deadline TEXT, all_sources INTEGER NOT NULL CHECK(all_sources IN (0,1)), "
                       "source_ids TEXT NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS accounts ("
                       "id TEXT PRIMARY KEY, name TEXT NOT NULL, "
                       "asset_type INTEGER NOT NULL CHECK(asset_type IN (0,1,2)), "
                       "account_type INTEGER NOT NULL CHECK(account_type IN (0,1,2,3,4,5,6,7)), "
                       "currency TEXT NOT NULL CHECK(currency IN ('RUB','USD','EUR')), "
                       "initial_balance_minor INTEGER NOT NULL DEFAULT 0, "
                       "credit_limit_minor INTEGER NOT NULL DEFAULT 0 "
                       "CHECK(credit_limit_minor >= 0), "
                       "is_archived INTEGER NOT NULL DEFAULT 0 CHECK(is_archived IN (0,1)), "
                       "created_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS categories ("
                       "id TEXT PRIMARY KEY, name TEXT NOT NULL, "
                       "type INTEGER NOT NULL CHECK(type IN (0,1)), "
                       "is_system INTEGER NOT NULL DEFAULT 0 CHECK(is_system IN (0,1)), "
                       "is_archived INTEGER NOT NULL DEFAULT 0 CHECK(is_archived IN (0,1)), "
                       "created_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS projects ("
                       "id TEXT PRIMARY KEY, "
                       "name TEXT NOT NULL CHECK(length(trim(name)) > 0), "
                       "is_archived INTEGER NOT NULL DEFAULT 0 "
                       "CHECK(is_archived IN (0,1)), "
                       "created_at INTEGER NOT NULL, "
                       "updated_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS budgets ("
                       "id TEXT PRIMARY KEY, "
                       "name TEXT NOT NULL CHECK(length(trim(name)) > 0), "
                       "currency TEXT NOT NULL CHECK(currency IN ('RUB','USD','EUR')), "
                       "default_limit_minor INTEGER NOT NULL CHECK(default_limit_minor > 0), "
                       "all_accounts INTEGER NOT NULL CHECK(all_accounts IN (0,1)), "
                       "all_categories INTEGER NOT NULL CHECK(all_categories IN (0,1)), "
                       "starts_on TEXT NOT NULL CHECK(length(starts_on) = 10), "
                       "is_archived INTEGER NOT NULL DEFAULT 0 CHECK(is_archived IN (0,1)), "
                       "created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS budget_accounts ("
                       "budget_id TEXT NOT NULL REFERENCES budgets(id) ON DELETE CASCADE, "
                       "account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE, "
                       "PRIMARY KEY(budget_id, account_id))"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS budget_category_limits ("
                       "budget_id TEXT NOT NULL REFERENCES budgets(id) ON DELETE CASCADE, "
                       "category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE CASCADE, "
                       "limit_minor INTEGER NOT NULL DEFAULT 0 CHECK(limit_minor >= 0), "
                       "PRIMARY KEY(budget_id, category_id))"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS budget_months ("
                       "budget_id TEXT NOT NULL REFERENCES budgets(id) ON DELETE CASCADE, "
                       "month TEXT NOT NULL CHECK(length(month) = 10), "
                       "limit_minor INTEGER NOT NULL CHECK(limit_minor > 0), "
                       "PRIMARY KEY(budget_id, month))"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS transactions ("
                       "id TEXT PRIMARY KEY, "
                       "account_id TEXT NOT NULL REFERENCES accounts(id), "
                       "category_id TEXT NOT NULL REFERENCES categories(id), "
                       "type INTEGER NOT NULL CHECK(type IN (0,1)), "
                       "amount_minor INTEGER NOT NULL CHECK(amount_minor > 0), "
                       "occurred_at INTEGER NOT NULL, description TEXT NOT NULL DEFAULT '', "
                       "project_id TEXT REFERENCES projects(id) ON DELETE SET NULL, "
                       "created_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS settings ("
                       "key TEXT PRIMARY KEY, value TEXT NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS bank_csv_profiles ("
                       "id TEXT PRIMARY KEY, "
                       "name TEXT NOT NULL CHECK(length(trim(name)) > 0), "
                       "configuration_json TEXT NOT NULL, "
                       "created_at INTEGER NOT NULL, "
                       "updated_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS recurring_transactions ("
                       "id TEXT PRIMARY KEY, "
                       "name TEXT NOT NULL CHECK(length(trim(name)) > 0), "
                       "account_id TEXT NOT NULL REFERENCES accounts(id), "
                       "category_id TEXT NOT NULL REFERENCES categories(id), "
                       "type INTEGER NOT NULL CHECK(type IN (0,1)), "
                       "amount_minor INTEGER NOT NULL CHECK(amount_minor > 0), "
                       "amount_currency TEXT NOT NULL "
                       "CHECK(amount_currency IN ('RUB','USD','EUR')), "
                       "recurrence_type INTEGER NOT NULL "
                       "CHECK(recurrence_type IN (0,1,2,3)), "
                       "weekday INTEGER NOT NULL CHECK(weekday BETWEEN 1 AND 7), "
                       "day_of_month INTEGER NOT NULL "
                       "CHECK(day_of_month BETWEEN 1 AND 31), "
                       "week_of_month INTEGER NOT NULL "
                       "CHECK(week_of_month BETWEEN 1 AND 5), "
                       "starts_on TEXT NOT NULL CHECK(length(starts_on) = 10), "
                       "generated_through TEXT NOT NULL "
                       "CHECK(length(generated_through) = 10), "
                       "created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS "
                       "recurring_transaction_occurrences ("
                       "recurring_id TEXT NOT NULL "
                       "REFERENCES recurring_transactions(id) ON DELETE CASCADE, "
                       "occurrence_date TEXT NOT NULL, "
                       "transaction_id TEXT NOT NULL UNIQUE "
                       "REFERENCES transactions(id) ON DELETE CASCADE, "
                       "PRIMARY KEY(recurring_id, occurrence_date))"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS crypto_wallets ("
                       "id TEXT PRIMARY KEY, address TEXT NOT NULL, "
                       "network TEXT NOT NULL, symbol TEXT NOT NULL, "
                       "decimals INTEGER NOT NULL, "
                       "balance_atomic INTEGER NOT NULL DEFAULT 0 "
                       "CHECK(balance_atomic >= 0), "
                       "balance_fetched_at INTEGER, "
                       "history_fetched_at INTEGER, "
                       "is_archived INTEGER NOT NULL DEFAULT 0 CHECK(is_archived IN (0,1)), "
                       "created_at INTEGER NOT NULL, "
                       "CHECK((network = 'TRON' AND symbol = 'USDT' AND decimals = 6) OR "
                       "      (network = 'BITCOIN' AND symbol = 'BTC' AND decimals = 8) OR "
                       "      (network = 'ETHEREUM' AND symbol = 'ETH' AND decimals = 8)))"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS crypto_prices ("
                       "symbol TEXT PRIMARY KEY "
                       "CHECK(symbol IN ('USDT','BTC','ETH')), "
                       "price_usd_micros INTEGER NOT NULL CHECK(price_usd_micros > 0), "
                       "fetched_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS crypto_transactions ("
                       "wallet_id TEXT NOT NULL REFERENCES crypto_wallets(id), "
                       "transaction_id TEXT NOT NULL, "
                       "from_address TEXT NOT NULL, "
                       "to_address TEXT NOT NULL, "
                       "amount_atomic INTEGER NOT NULL CHECK(amount_atomic > 0), "
                       "occurred_at INTEGER NOT NULL, "
                       "PRIMARY KEY(wallet_id, transaction_id))"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS investment_instruments ("
                       "id TEXT PRIMARY KEY, "
                       "symbol TEXT NOT NULL CHECK(length(trim(symbol)) > 0), "
                       "isin TEXT NOT NULL DEFAULT '', "
                       "name TEXT NOT NULL CHECK(length(trim(name)) > 0), "
                       "type INTEGER NOT NULL CHECK(type IN (0,1,2,3,4)), "
                       "currency TEXT NOT NULL CHECK(currency IN ('RUB','USD','EUR')), "
                       "market_code TEXT NOT NULL DEFAULT '', "
                       "primary_board_id TEXT NOT NULL DEFAULT '', "
                       "is_archived INTEGER NOT NULL DEFAULT 0 CHECK(is_archived IN (0,1)), "
                       "created_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS investment_positions ("
                       "id TEXT PRIMARY KEY, "
                       "account_id TEXT NOT NULL REFERENCES accounts(id), "
                       "instrument_id TEXT NOT NULL REFERENCES investment_instruments(id), "
                       "quantity_micros INTEGER NOT NULL CHECK(quantity_micros > 0), "
                       "average_price_micros INTEGER NOT NULL "
                       "CHECK(average_price_micros >= 0), "
                       "is_archived INTEGER NOT NULL DEFAULT 0 CHECK(is_archived IN (0,1)), "
                       "created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE TABLE IF NOT EXISTS investment_quotes ("
                       "instrument_id TEXT PRIMARY KEY "
                       "REFERENCES investment_instruments(id), "
                       "price_micros INTEGER NOT NULL CHECK(price_micros > 0), "
                       "quoted_at INTEGER NOT NULL)"),
        QStringLiteral("CREATE UNIQUE INDEX IF NOT EXISTS "
                       "idx_crypto_wallets_active_address "
                       "ON crypto_wallets(network, address) "
                       "WHERE is_archived = 0"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS idx_transactions_occurred_at "
                       "ON transactions(occurred_at DESC)"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS idx_transactions_account_date "
                       "ON transactions(account_id, occurred_at DESC)"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS idx_transactions_category "
                       "ON transactions(category_id)"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS idx_budget_accounts_account "
                       "ON budget_accounts(account_id)"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS idx_budget_categories_category "
                       "ON budget_category_limits(category_id)"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS "
                       "idx_recurring_transactions_account "
                       "ON recurring_transactions(account_id)"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS "
                       "idx_recurring_transactions_category "
                       "ON recurring_transactions(category_id)"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS "
                       "idx_crypto_transactions_wallet_date "
                       "ON crypto_transactions(wallet_id, occurred_at DESC)"),
        QStringLiteral("CREATE UNIQUE INDEX IF NOT EXISTS "
                       "idx_investment_positions_active_account_instrument "
                       "ON investment_positions(account_id, instrument_id) "
                       "WHERE is_archived = 0"),
        QStringLiteral("CREATE UNIQUE INDEX IF NOT EXISTS "
                       "idx_investment_instruments_active_isin "
                       "ON investment_instruments(isin) "
                       "WHERE is_archived = 0 AND isin <> ''"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS "
                       "idx_investment_positions_instrument "
                       "ON investment_positions(instrument_id)"),
        QStringLiteral("CREATE INDEX IF NOT EXISTS "
                       "idx_investment_positions_account "
                       "ON investment_positions(account_id)")
    };

    for (const QString& statement : statements) {
        QSqlQuery query(database_);
        if (!query.exec(statement)) {
            setLastError(query.lastError().text());
            return false;
        }
    }
    return true;
}

bool FinanceRepository::migrateLegacySchema()
{
    QSqlQuery columns(database_);
    if (!columns.exec(QStringLiteral("PRAGMA table_info(accounts)"))) {
        setLastError(columns.lastError().text());
        return false;
    }

    bool hasLegacyGroupType = false;
    bool hasAssetType = false;
    bool hasCreditLimit = false;
    while (columns.next()) {
        const QString name = columns.value(1).toString();
        hasLegacyGroupType = hasLegacyGroupType ||
            name == QStringLiteral("group_type");
        hasAssetType = hasAssetType ||
            name == QStringLiteral("asset_type");
        hasCreditLimit = hasCreditLimit ||
            name == QStringLiteral("credit_limit_minor");
    }
    columns.finish();

    QSqlQuery transactionColumns(database_);
    if (!transactionColumns.exec(QStringLiteral(
            "PRAGMA table_info(transactions)"))) {
        setLastError(transactionColumns.lastError().text());
        return false;
    }
    bool hasTransactionProjectId = false;
    while (transactionColumns.next()) {
        hasTransactionProjectId = hasTransactionProjectId ||
            transactionColumns.value(1).toString() ==
                QStringLiteral("project_id");
    }
    transactionColumns.finish();

    QSqlQuery projectColumns(database_);
    if (!projectColumns.exec(QStringLiteral("PRAGMA table_info(projects)"))) {
        setLastError(projectColumns.lastError().text());
        return false;
    }
    bool hasProjectArchived = false;
    bool hasProjectCreatedAt = false;
    bool hasProjectUpdatedAt = false;
    while (projectColumns.next()) {
        const QString name = projectColumns.value(1).toString();
        hasProjectArchived = hasProjectArchived ||
            name == QStringLiteral("is_archived");
        hasProjectCreatedAt = hasProjectCreatedAt ||
            name == QStringLiteral("created_at");
        hasProjectUpdatedAt = hasProjectUpdatedAt ||
            name == QStringLiteral("updated_at");
    }
    projectColumns.finish();

    QSqlQuery cryptoColumns(database_);
    if (!cryptoColumns.exec(QStringLiteral(
            "PRAGMA table_info(crypto_wallets)"))) {
        setLastError(cryptoColumns.lastError().text());
        return false;
    }
    bool hasCryptoHistoryFetchedAt = false;
    bool hasCryptoDecimals = false;
    while (cryptoColumns.next()) {
        hasCryptoHistoryFetchedAt = hasCryptoHistoryFetchedAt ||
            cryptoColumns.value(1).toString() ==
                QStringLiteral("history_fetched_at");
        hasCryptoDecimals = hasCryptoDecimals ||
            cryptoColumns.value(1).toString() == QStringLiteral("decimals");
    }
    cryptoColumns.finish();

    QSqlQuery investmentColumns(database_);
    if (!investmentColumns.exec(QStringLiteral(
            "PRAGMA table_info(investment_instruments)"))) {
        setLastError(investmentColumns.lastError().text());
        return false;
    }
    bool hasInvestmentMarketCode = false;
    bool hasInvestmentPrimaryBoardId = false;
    while (investmentColumns.next()) {
        const QString name = investmentColumns.value(1).toString();
        hasInvestmentMarketCode = hasInvestmentMarketCode ||
            name == QStringLiteral("market_code");
        hasInvestmentPrimaryBoardId = hasInvestmentPrimaryBoardId ||
            name == QStringLiteral("primary_board_id");
    }
    investmentColumns.finish();

    QSqlQuery accountSchema(database_);
    if (!accountSchema.exec(QStringLiteral(
            "SELECT sql FROM sqlite_master "
            "WHERE type = 'table' AND name = 'accounts'")) ||
        !accountSchema.next()) {
        setLastError(accountSchema.lastError().isValid()
            ? accountSchema.lastError().text()
            : QStringLiteral("Accounts table schema was not found"));
        return false;
    }
    const QString accountTableSql = accountSchema.value(0).toString();
    accountSchema.finish();
    const bool needsAccountTypeExpansion =
        !accountTableSql.contains(QStringLiteral(",5,6,7"));

    QSqlQuery recurringSchema(database_);
    if (!recurringSchema.exec(QStringLiteral(
            "SELECT sql FROM sqlite_master "
            "WHERE type = 'table' AND name = 'recurring_transactions'")) ||
        !recurringSchema.next()) {
        setLastError(recurringSchema.lastError().isValid()
            ? recurringSchema.lastError().text()
            : QStringLiteral("Recurring transactions table schema was not found"));
        return false;
    }
    const QString recurringTableSql = recurringSchema.value(0).toString();
    recurringSchema.finish();
    const bool needsRecurringTypeExpansion =
        !recurringTableSql.contains(QStringLiteral("0,1,2,3"));

    QSqlQuery recurringColumns(database_);
    if (!recurringColumns.exec(QStringLiteral(
            "PRAGMA table_info(recurring_transactions)"))) {
        setLastError(recurringColumns.lastError().text());
        return false;
    }
    bool hasRecurringAmountCurrency = false;
    while (recurringColumns.next()) {
        hasRecurringAmountCurrency = hasRecurringAmountCurrency ||
            recurringColumns.value(1).toString() ==
                QStringLiteral("amount_currency");
    }
    recurringColumns.finish();

    const bool needsAssetTypeRename = hasLegacyGroupType && !hasAssetType;
    if (!needsAssetTypeRename && hasCreditLimit &&
        hasCryptoHistoryFetchedAt && hasCryptoDecimals &&
        hasInvestmentMarketCode && hasInvestmentPrimaryBoardId &&
        !needsAccountTypeExpansion && !needsRecurringTypeExpansion &&
        hasRecurringAmountCurrency && hasTransactionProjectId &&
        hasProjectArchived && hasProjectCreatedAt && hasProjectUpdatedAt) {
        QSqlQuery projectIndex(database_);
        if (!projectIndex.exec(QStringLiteral(
                "CREATE INDEX IF NOT EXISTS idx_transactions_project_date "
                "ON transactions(project_id, occurred_at DESC)"))) {
            setLastError(projectIndex.lastError().text());
            return false;
        }
        return true;
    }
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    QSqlQuery migration(database_);
    if (!hasProjectArchived &&
        !migration.exec(QStringLiteral(
            "ALTER TABLE projects ADD COLUMN is_archived INTEGER NOT NULL "
            "DEFAULT 0 CHECK(is_archived IN (0,1))"))) {
        setLastError(migration.lastError().text());
        database_.rollback();
        return false;
    }
    if (!hasProjectCreatedAt &&
        !migration.exec(QStringLiteral(
            "ALTER TABLE projects ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0"))) {
        setLastError(migration.lastError().text());
        database_.rollback();
        return false;
    }
    if (!hasProjectUpdatedAt &&
        !migration.exec(QStringLiteral(
            "ALTER TABLE projects ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0"))) {
        setLastError(migration.lastError().text());
        database_.rollback();
        return false;
    }
    if (!hasInvestmentMarketCode &&
        !migration.exec(QStringLiteral(
            "ALTER TABLE investment_instruments ADD COLUMN "
            "market_code TEXT NOT NULL DEFAULT ''"))) {
        setLastError(migration.lastError().text());
        database_.rollback();
        return false;
    }
    if (!hasInvestmentPrimaryBoardId &&
        !migration.exec(QStringLiteral(
            "ALTER TABLE investment_instruments ADD COLUMN "
            "primary_board_id TEXT NOT NULL DEFAULT ''"))) {
        setLastError(migration.lastError().text());
        database_.rollback();
        return false;
    }
    if (needsAssetTypeRename &&
        !migration.exec(QStringLiteral(
            "ALTER TABLE accounts RENAME COLUMN group_type TO asset_type"))) {
        setLastError(migration.lastError().text());
        database_.rollback();
        return false;
    }

    if (!hasTransactionProjectId &&
        !migration.exec(QStringLiteral(
            "ALTER TABLE transactions ADD COLUMN "
            "project_id TEXT REFERENCES projects(id) ON DELETE SET NULL"))) {
        setLastError(migration.lastError().text());
        database_.rollback();
        return false;
    }

    if (!hasCreditLimit) {
        if (!migration.exec(QStringLiteral(
                "ALTER TABLE accounts ADD COLUMN "
                "credit_limit_minor INTEGER NOT NULL DEFAULT 0 "
                "CHECK(credit_limit_minor >= 0)"))) {
            setLastError(migration.lastError().text());
            database_.rollback();
            return false;
        }

        // Before credit cards had their own semantics, a positive initial
        // balance was commonly used as the available credit. Preserve that
        // intent by turning it into a limit instead of counting bank money as
        // the user's asset.
        if (!migration.exec(QStringLiteral(
                "UPDATE accounts "
                "SET credit_limit_minor = initial_balance_minor, "
                "    initial_balance_minor = 0 "
                "WHERE account_type = %1 AND initial_balance_minor > 0")
                .arg(static_cast<int>(AccountType::CreditCard)))) {
            setLastError(migration.lastError().text());
            database_.rollback();
            return false;
        }
    }

    if (!hasCryptoHistoryFetchedAt &&
        !migration.exec(QStringLiteral(
            "ALTER TABLE crypto_wallets ADD COLUMN "
            "history_fetched_at INTEGER"))) {
        setLastError(migration.lastError().text());
        database_.rollback();
        return false;
    }

    if (!hasCryptoDecimals) {
        const QStringList cryptoMigrationStatements{
            QStringLiteral(
                "CREATE TABLE crypto_wallets_v2 ("
                "id TEXT PRIMARY KEY, address TEXT NOT NULL, "
                "network TEXT NOT NULL, symbol TEXT NOT NULL, "
                "decimals INTEGER NOT NULL, "
                "balance_atomic INTEGER NOT NULL DEFAULT 0 CHECK(balance_atomic >= 0), "
                "balance_fetched_at INTEGER, history_fetched_at INTEGER, "
                "is_archived INTEGER NOT NULL DEFAULT 0 CHECK(is_archived IN (0,1)), "
                "created_at INTEGER NOT NULL, "
                "CHECK((network = 'TRON' AND symbol = 'USDT' AND decimals = 6) OR "
                "      (network = 'BITCOIN' AND symbol = 'BTC' AND decimals = 8) OR "
                "      (network = 'ETHEREUM' AND symbol = 'ETH' AND decimals = 8)))"),
            QStringLiteral(
                "INSERT INTO crypto_wallets_v2("
                "id,address,network,symbol,decimals,balance_atomic,"
                "balance_fetched_at,history_fetched_at,is_archived,created_at) "
                "SELECT id,address,network,symbol,6,balance_atomic,"
                "balance_fetched_at,history_fetched_at,is_archived,created_at "
                "FROM crypto_wallets"),
            QStringLiteral(
                "CREATE TABLE crypto_transactions_v2 ("
                "wallet_id TEXT NOT NULL REFERENCES crypto_wallets_v2(id), "
                "transaction_id TEXT NOT NULL, from_address TEXT NOT NULL, "
                "to_address TEXT NOT NULL, amount_atomic INTEGER NOT NULL "
                "CHECK(amount_atomic > 0), occurred_at INTEGER NOT NULL, "
                "PRIMARY KEY(wallet_id, transaction_id))"),
            QStringLiteral(
                "INSERT INTO crypto_transactions_v2 "
                "SELECT * FROM crypto_transactions"),
            QStringLiteral(
                "CREATE TABLE crypto_prices_v2 ("
                "symbol TEXT PRIMARY KEY CHECK(symbol IN ('USDT','BTC','ETH')), "
                "price_usd_micros INTEGER NOT NULL CHECK(price_usd_micros > 0), "
                "fetched_at INTEGER NOT NULL)"),
            QStringLiteral(
                "INSERT INTO crypto_prices_v2 SELECT * FROM crypto_prices"),
            QStringLiteral("DROP TABLE crypto_transactions"),
            QStringLiteral("DROP TABLE crypto_wallets"),
            QStringLiteral("DROP TABLE crypto_prices"),
            QStringLiteral("ALTER TABLE crypto_wallets_v2 RENAME TO crypto_wallets"),
            QStringLiteral("ALTER TABLE crypto_prices_v2 RENAME TO crypto_prices"),
            QStringLiteral("ALTER TABLE crypto_transactions_v2 RENAME TO crypto_transactions"),
            QStringLiteral(
                "CREATE UNIQUE INDEX idx_crypto_wallets_active_address "
                "ON crypto_wallets(network, address) WHERE is_archived = 0"),
            QStringLiteral(
                "CREATE INDEX idx_crypto_transactions_wallet_date "
                "ON crypto_transactions(wallet_id, occurred_at DESC)")};
        for (const QString& statement : cryptoMigrationStatements) {
            if (!migration.exec(statement)) {
                setLastError(migration.lastError().text());
                database_.rollback();
                return false;
            }
        }
    }

    if (!database_.commit()) {
        setLastError(database_.lastError().text());
        database_.rollback();
        return false;
    }

    if (needsAccountTypeExpansion) {
        QSqlQuery foreignKeys(database_);
        if (!foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = OFF"))) {
            setLastError(foreignKeys.lastError().text());
            return false;
        }
        if (!database_.transaction()) {
            setLastError(database_.lastError().text());
            foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = ON"));
            return false;
        }

        const QStringList accountMigrationStatements{
            QStringLiteral(
                "CREATE TABLE accounts_v2 ("
                "id TEXT PRIMARY KEY, name TEXT NOT NULL, "
                "asset_type INTEGER NOT NULL CHECK(asset_type IN (0,1,2)), "
                "account_type INTEGER NOT NULL "
                "CHECK(account_type IN (0,1,2,3,4,5,6,7)), "
                "currency TEXT NOT NULL CHECK(currency IN ('RUB','USD','EUR')), "
                "initial_balance_minor INTEGER NOT NULL DEFAULT 0, "
                "credit_limit_minor INTEGER NOT NULL DEFAULT 0 "
                "CHECK(credit_limit_minor >= 0), "
                "is_archived INTEGER NOT NULL DEFAULT 0 "
                "CHECK(is_archived IN (0,1)), created_at INTEGER NOT NULL)"),
            QStringLiteral(
                "INSERT INTO accounts_v2("
                "id,name,asset_type,account_type,currency,"
                "initial_balance_minor,credit_limit_minor,is_archived,created_at) "
                "SELECT id,name,asset_type,account_type,currency,"
                "initial_balance_minor,credit_limit_minor,is_archived,created_at "
                "FROM accounts"),
            QStringLiteral("DROP TABLE accounts"),
            QStringLiteral("ALTER TABLE accounts_v2 RENAME TO accounts")};

        QSqlQuery accountMigration(database_);
        for (const QString& statement : accountMigrationStatements) {
            if (!accountMigration.exec(statement)) {
                setLastError(accountMigration.lastError().text());
                database_.rollback();
                foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = ON"));
                return false;
            }
        }
        if (!database_.commit()) {
            setLastError(database_.lastError().text());
            database_.rollback();
            foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = ON"));
            return false;
        }
        if (!foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = ON"))) {
            setLastError(foreignKeys.lastError().text());
            return false;
        }

        QSqlQuery foreignKeyCheck(database_);
        if (!foreignKeyCheck.exec(QStringLiteral("PRAGMA foreign_key_check"))) {
            setLastError(foreignKeyCheck.lastError().text());
            return false;
        }
        if (foreignKeyCheck.next()) {
            setLastError(QStringLiteral(
                "Foreign key violation after accounts migration"));
            return false;
        }
    }

    if (needsRecurringTypeExpansion) {
        QSqlQuery foreignKeys(database_);
        if (!foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = OFF"))) {
            setLastError(foreignKeys.lastError().text());
            return false;
        }
        if (!database_.transaction()) {
            setLastError(database_.lastError().text());
            foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = ON"));
            return false;
        }

        const QStringList recurringMigrationStatements{
            QStringLiteral(
                "CREATE TABLE recurring_transactions_v2 ("
                "id TEXT PRIMARY KEY, "
                "name TEXT NOT NULL CHECK(length(trim(name)) > 0), "
                "account_id TEXT NOT NULL REFERENCES accounts(id), "
                "category_id TEXT NOT NULL REFERENCES categories(id), "
                "type INTEGER NOT NULL CHECK(type IN (0,1)), "
                "amount_minor INTEGER NOT NULL CHECK(amount_minor > 0), "
                "recurrence_type INTEGER NOT NULL "
                "CHECK(recurrence_type IN (0,1,2,3)), "
                "weekday INTEGER NOT NULL CHECK(weekday BETWEEN 1 AND 7), "
                "day_of_month INTEGER NOT NULL "
                "CHECK(day_of_month BETWEEN 1 AND 31), "
                "week_of_month INTEGER NOT NULL "
                "CHECK(week_of_month BETWEEN 1 AND 5), "
                "starts_on TEXT NOT NULL CHECK(length(starts_on) = 10), "
                "generated_through TEXT NOT NULL "
                "CHECK(length(generated_through) = 10), "
                "created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)"),
            QStringLiteral(
                "INSERT INTO recurring_transactions_v2 "
                "SELECT * FROM recurring_transactions"),
            QStringLiteral("DROP TABLE recurring_transactions"),
            QStringLiteral(
                "ALTER TABLE recurring_transactions_v2 "
                "RENAME TO recurring_transactions"),
            QStringLiteral(
                "CREATE INDEX idx_recurring_transactions_account "
                "ON recurring_transactions(account_id)"),
            QStringLiteral(
                "CREATE INDEX idx_recurring_transactions_category "
                "ON recurring_transactions(category_id)")};

        QSqlQuery recurringMigration(database_);
        for (const QString& statement : recurringMigrationStatements) {
            if (!recurringMigration.exec(statement)) {
                setLastError(recurringMigration.lastError().text());
                database_.rollback();
                foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = ON"));
                return false;
            }
        }
        if (!database_.commit()) {
            setLastError(database_.lastError().text());
            database_.rollback();
            foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = ON"));
            return false;
        }
        if (!foreignKeys.exec(QStringLiteral("PRAGMA foreign_keys = ON"))) {
            setLastError(foreignKeys.lastError().text());
            return false;
        }

        QSqlQuery foreignKeyCheck(database_);
        if (!foreignKeyCheck.exec(QStringLiteral("PRAGMA foreign_key_check"))) {
            setLastError(foreignKeyCheck.lastError().text());
            return false;
        }
        if (foreignKeyCheck.next()) {
            setLastError(QStringLiteral(
                "Foreign key violation after recurring transactions migration"));
            return false;
        }
    }

    if (!hasRecurringAmountCurrency) {
        if (!database_.transaction()) {
            setLastError(database_.lastError().text());
            return false;
        }
        QSqlQuery recurringCurrencyMigration(database_);
        const QStringList statements{
            QStringLiteral(
                "ALTER TABLE recurring_transactions ADD COLUMN "
                "amount_currency TEXT NOT NULL DEFAULT 'RUB' "
                "CHECK(amount_currency IN ('RUB','USD','EUR'))"),
            QStringLiteral(
                "UPDATE recurring_transactions "
                "SET amount_currency = COALESCE(("
                "SELECT currency FROM accounts "
                "WHERE accounts.id = recurring_transactions.account_id"
                "), 'RUB')")};
        for (const QString& statement : statements) {
            if (!recurringCurrencyMigration.exec(statement)) {
                setLastError(recurringCurrencyMigration.lastError().text());
                database_.rollback();
                return false;
            }
        }
        if (!database_.commit()) {
            setLastError(database_.lastError().text());
            database_.rollback();
            return false;
        }
    }

    QSqlQuery projectIndex(database_);
    if (!projectIndex.exec(QStringLiteral(
            "CREATE INDEX IF NOT EXISTS idx_transactions_project_date "
            "ON transactions(project_id, occurred_at DESC)"))) {
        setLastError(projectIndex.lastError().text());
        return false;
    }
    return true;
}

bool FinanceRepository::seedDefaults()
{
    if (!database_.transaction()) {
        setLastError(database_.lastError().text());
        return false;
    }

    const qint64 now = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    QSqlQuery account(database_);
    account.prepare(QStringLiteral(
        "INSERT OR IGNORE INTO accounts(id,name,asset_type,account_type,currency,created_at) "
        "VALUES (?, ?, 0, 4, ?, ?)"));
    const std::array<QString, 3> currencies{
        QStringLiteral("RUB"), QStringLiteral("USD"), QStringLiteral("EUR")};
    for (const QString& currency : currencies) {
        account.bindValue(0, QStringLiteral("household-") + currency.toLower());
        account.bindValue(1, QStringLiteral("Основной ") + currency);
        account.bindValue(2, currency);
        account.bindValue(3, now);
        if (!account.exec()) {
            setLastError(account.lastError().text());
            database_.rollback();
            return false;
        }
    }

    struct Seed { QString id; QString name; int type; };
    const Seed seeds[] = {
        {QStringLiteral("salary"), QStringLiteral("Зарплата"), 0},
        {QStringLiteral("freelance"), QStringLiteral("Фриланс"), 0},
        {QStringLiteral("gift"), QStringLiteral("Подарок"), 0},
        {QStringLiteral("investment"), QStringLiteral("Инвестиции"), 0},
        {QStringLiteral("other_income"), QStringLiteral("Другой доход"), 0},
        {QStringLiteral("groceries"), QStringLiteral("Продукты"), 1},
        {QStringLiteral("transport"), QStringLiteral("Транспорт"), 1},
        {QStringLiteral("housing"), QStringLiteral("Жилье"), 1},
        {QStringLiteral("health"), QStringLiteral("Здоровье"), 1},
        {QStringLiteral("entertainment"), QStringLiteral("Развлечения"), 1},
        {QStringLiteral("shopping"), QStringLiteral("Покупки"), 1},
        {QStringLiteral("other_expense"), QStringLiteral("Другое"), 1},
        {QStringLiteral("transfer-in"), QStringLiteral("Перевод"), 0},
        {QStringLiteral("transfer-out"), QStringLiteral("Перевод"), 1}};
    QSqlQuery category(database_);
    category.prepare(QStringLiteral(
        "INSERT OR IGNORE INTO categories(id,name,type,is_system,created_at) "
        "VALUES (?, ?, ?, 1, ?)"));
    for (const Seed& seed : seeds) {
        category.bindValue(0, seed.id);
        category.bindValue(1, seed.name);
        category.bindValue(2, seed.type);
        category.bindValue(3, now);
        if (!category.exec()) {
            setLastError(category.lastError().text());
            database_.rollback();
            return false;
        }
    }

    QSqlQuery setting(database_);
    if (!setting.exec(QStringLiteral(
            "INSERT OR IGNORE INTO settings(key,value) VALUES('app_currency','RUB')")) ||
        !setting.exec(QStringLiteral(
            "INSERT OR IGNORE INTO settings(key,value) VALUES('selected_asset','fiat')")) ||
        !setting.exec(QStringLiteral(
            "INSERT OR IGNORE INTO settings(key,value) VALUES('ui_language','ru')")) ||
        !setting.exec(QStringLiteral(
            "INSERT OR IGNORE INTO settings(key,value) "
            "VALUES('automatic_currency_rates','1')")) ||
        !setting.exec(QStringLiteral(
            "INSERT OR IGNORE INTO settings(key,value) "
            "VALUES('manual_rub_to_rub_rate','1')")) ||
        !setting.exec(QStringLiteral(
            "INSERT OR IGNORE INTO settings(key,value) "
            "VALUES('manual_usd_to_rub_rate','90.909090909')")) ||
        !setting.exec(QStringLiteral(
            "INSERT OR IGNORE INTO settings(key,value) "
            "VALUES('manual_eur_to_rub_rate','106.363636364')")) ||
        !database_.commit()) {
        setLastError(setting.lastError().isValid()
                         ? setting.lastError().text()
                         : database_.lastError().text());
        database_.rollback();
        return false;
    }
    return true;
}

void FinanceRepository::setLastError(const QString& error) { lastError_ = error; }

QVector<FinancialGoal> FinanceRepository::loadFinancialGoals()
{
    QVector<FinancialGoal> goals;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT id,name,currency,target_minor,deadline,all_sources,source_ids "
            "FROM financial_goals ORDER BY rowid"))) {
        setLastError(query.lastError().text());
        return goals;
    }
    while (query.next()) {
        FinancialGoal goal;
        goal.id = query.value(0).toString();
        goal.name = query.value(1).toString();
        goal.currency = currencyFromCode(query.value(2).toString());
        goal.targetMinor = query.value(3).toLongLong();
        goal.deadline = QDate::fromString(query.value(4).toString(), Qt::ISODate);
        goal.allSources = query.value(5).toBool();
        const auto sources = QJsonDocument::fromJson(query.value(6).toByteArray()).array();
        for (const auto& source : sources) goal.sourceIds.append(source.toString());
        goals.append(goal);
    }
    return goals;
}

bool FinanceRepository::saveFinancialGoal(const FinancialGoal& goal, bool editing)
{
    if (goal.id.isEmpty() || goal.name.trimmed().isEmpty() || goal.name.size() > 80 ||
        goal.targetMinor <= 0 || (!goal.allSources && goal.sourceIds.isEmpty())) {
        setLastError(QStringLiteral("Invalid financial goal"));
        return false;
    }
    QSqlQuery query(database_);
    query.prepare(editing ? QStringLiteral(
        "UPDATE financial_goals SET name=?,currency=?,target_minor=?,deadline=?,"
        "all_sources=?,source_ids=? WHERE id=?") : QStringLiteral(
        "INSERT INTO financial_goals(name,currency,target_minor,deadline,all_sources,source_ids,id) "
        "VALUES(?,?,?,?,?,?,?)"));
    query.addBindValue(goal.name.trimmed());
    query.addBindValue(currencyCode(goal.currency));
    query.addBindValue(goal.targetMinor);
    query.addBindValue(goal.deadline.isValid() ? QVariant(goal.deadline.toString(Qt::ISODate)) : QVariant());
    query.addBindValue(goal.allSources ? 1 : 0);
    query.addBindValue(QString::fromUtf8(QJsonDocument(
        QJsonArray::fromStringList(goal.sourceIds)).toJson(QJsonDocument::Compact)));
    query.addBindValue(goal.id);
    if (!query.exec()) { setLastError(query.lastError().text()); return false; }
    if (query.numRowsAffected() != 1) {
        setLastError(QStringLiteral("Financial goal not found")); return false;
    }
    return true;
}

bool FinanceRepository::deleteFinancialGoal(const QString& id)
{
    QSqlQuery query(database_);
    query.prepare(QStringLiteral("DELETE FROM financial_goals WHERE id=?"));
    query.addBindValue(id);
    if (!query.exec()) { setLastError(query.lastError().text()); return false; }
    return query.numRowsAffected() == 1;
}

QVector<CapitalSnapshot> FinanceRepository::loadCapitalSnapshots()
{
    QVector<CapitalSnapshot> snapshots;
    QSqlQuery query(database_);
    if (!query.exec(QStringLiteral(
            "SELECT snapshot_date,currency,total_minor FROM capital_snapshots "
            "ORDER BY snapshot_date"))) {
        setLastError(query.lastError().text());
        return snapshots;
    }
    while (query.next()) {
        snapshots.append({QDate::fromString(query.value(0).toString(), Qt::ISODate),
                          currencyFromCode(query.value(1).toString()),
                          query.value(2).toLongLong()});
    }
    return snapshots;
}

bool FinanceRepository::saveCapitalSnapshot(const CapitalSnapshot& snapshot)
{
    if (!snapshot.date.isValid()) {
        setLastError(QStringLiteral("Invalid capital snapshot"));
        return false;
    }
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO capital_snapshots(snapshot_date,currency,total_minor,updated_at) "
        "VALUES(?,?,?,?) ON CONFLICT(snapshot_date) DO UPDATE SET "
        "currency=excluded.currency,total_minor=excluded.total_minor,updated_at=excluded.updated_at"));
    query.addBindValue(snapshot.date.toString(Qt::ISODate));
    query.addBindValue(currencyCode(snapshot.currency));
    query.addBindValue(snapshot.totalMinor);
    query.addBindValue(QDateTime::currentDateTimeUtc().toMSecsSinceEpoch());
    if (!query.exec()) { setLastError(query.lastError().text()); return false; }
    return true;
}

FinancialTrajectorySettings FinanceRepository::loadFinancialTrajectorySettings() const
{
    FinancialTrajectorySettings result;
    QSqlQuery query(database_);
    query.prepare(QStringLiteral("SELECT value FROM settings WHERE key=?"));
    const auto value = [&query](const QString& key, const QVariant& fallback) {
        query.bindValue(0, key);
        if (!query.exec() || !query.next()) { query.finish(); return fallback; }
        const QVariant result = query.value(0); query.finish(); return result;
    };
    result.analysisMonths = value(QStringLiteral("trajectory_analysis_months"), 6).toInt();
    result.horizonMonths = value(QStringLiteral("trajectory_horizon_months"), 12).toInt();
    result.annualReturnPercent = value(QStringLiteral("trajectory_return"), 5.0).toDouble();
    result.annualInflationPercent = value(QStringLiteral("trajectory_inflation"), 6.0).toDouble();
    result.incomeChangePercent = value(QStringLiteral("trajectory_income_change"), 0.0).toDouble();
    result.expenseChangePercent = value(QStringLiteral("trajectory_expense_change"), 0.0).toDouble();
    result.purchaseMinor = value(QStringLiteral("trajectory_purchase_minor"), 0).toLongLong();
    result.purchaseMonth = value(QStringLiteral("trajectory_purchase_month"), 0).toInt();
    return result;
}

bool FinanceRepository::saveFinancialTrajectorySettings(
    const FinancialTrajectorySettings& settings)
{
    if (!database_.transaction()) { setLastError(database_.lastError().text()); return false; }
    QSqlQuery query(database_);
    query.prepare(QStringLiteral(
        "INSERT INTO settings(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value"));
    const QVector<QPair<QString, QVariant>> values{
        {QStringLiteral("trajectory_analysis_months"), settings.analysisMonths},
        {QStringLiteral("trajectory_horizon_months"), settings.horizonMonths},
        {QStringLiteral("trajectory_return"), settings.annualReturnPercent},
        {QStringLiteral("trajectory_inflation"), settings.annualInflationPercent},
        {QStringLiteral("trajectory_income_change"), settings.incomeChangePercent},
        {QStringLiteral("trajectory_expense_change"), settings.expenseChangePercent},
        {QStringLiteral("trajectory_purchase_minor"), settings.purchaseMinor},
        {QStringLiteral("trajectory_purchase_month"), settings.purchaseMonth}};
    for (const auto& item : values) {
        query.bindValue(0, item.first); query.bindValue(1, item.second);
        if (!query.exec()) { setLastError(query.lastError().text()); database_.rollback(); return false; }
        query.finish();
    }
    if (!database_.commit()) { setLastError(database_.lastError().text()); return false; }
    return true;
}
