#include "../persistence/FinanceRepository.h"

#include <QSqlError>
#include <QSqlQuery>
#include <QSet>
#include <QTemporaryDir>
#include <QTimeZone>
#include <QUuid>
#include <QtTest>

class FinanceRepositoryTest : public QObject
{
    Q_OBJECT

private slots:
    void financialGoalsCrudPersistsWithoutContributions();
    void storesCapitalSnapshotsAndTrajectorySettings();
    void preservesSelectedAccountAfterReopen();
    void storesUiLanguage();
    void storesCurrencyRateSettings();
    void storesBankCsvProfiles();
    void storesProjectsAndTransactionAssignments();
    void migratesProjectAssignmentForExistingDatabase();
    void migratesLegacyProjectTable();
    void storesUpdatesAndArchivesBudgets();
    void storesAndMaterializesRecurringTransactions();
    void storesCreditCardTerms();
    void migratesCreditLimitForExistingDatabase();
    void updatesAndDeletesTransaction();
    void storesTransferAtomicallyWithoutAffectingIncomeAndExpense();
    void replacesIncomeWithTransferAtomically();
    void deletesWholeTransferFromEitherComponent();
    void replacesTransferWithTransactionAtomically();
    void updatesAccountAndProtectsTransactionCurrency();
    void deletesAccountWithRelatedOperations();
    void storesCryptoWalletAndPriceSnapshots();
    void migratesLegacyCryptoSchema();
};

void FinanceRepositoryTest::storesCapitalSnapshotsAndTrajectorySettings()
{
    QTemporaryDir directory;
    QVERIFY(directory.isValid());
    const QString path = directory.filePath(QStringLiteral("trajectory.sqlite3"));
    {
        FinanceRepository repository(path);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        QVERIFY(repository.saveCapitalSnapshot({QDate(2026, 9, 21), Currency::USD, 100'000}));
        QVERIFY(repository.saveCapitalSnapshot({QDate(2026, 9, 22), Currency::RUB, 9'000'000}));
        QVERIFY(repository.saveCapitalSnapshot({QDate(2026, 9, 22), Currency::RUB, 9'500'000}));
        FinancialTrajectorySettings settings;
        settings.analysisMonths = 12; settings.horizonMonths = 60;
        settings.annualReturnPercent = 7.5; settings.purchaseMinor = 150'000;
        settings.purchaseMonth = 6;
        QVERIFY(repository.saveFinancialTrajectorySettings(settings));
    }
    {
        FinanceRepository repository(path);
        const auto snapshots = repository.loadCapitalSnapshots();
        QCOMPARE(snapshots.size(), 2);
        QCOMPARE(snapshots.last().totalMinor, 9'500'000);
        const auto settings = repository.loadFinancialTrajectorySettings();
        QCOMPARE(settings.analysisMonths, 12);
        QCOMPARE(settings.horizonMonths, 60);
        QCOMPARE(settings.annualReturnPercent, 7.5);
        QCOMPARE(settings.purchaseMinor, 150'000);
        QCOMPARE(settings.purchaseMonth, 6);
    }
}

void FinanceRepositoryTest::financialGoalsCrudPersistsWithoutContributions()
{
    QTemporaryDir directory;
    QVERIFY(directory.isValid());
    const QString path = directory.filePath(QStringLiteral("goals.sqlite3"));
    FinancialGoal goal;
    goal.id = QStringLiteral("goal"); goal.name = QStringLiteral("Capital");
    goal.currency = Currency::USD; goal.targetMinor = 20'000'000;
    {
        FinanceRepository repository(path);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        QVERIFY(repository.saveFinancialGoal(goal, false));
        QCOMPARE(repository.loadFinancialGoals().size(), 1);
        QVERIFY(!repository.saveFinancialGoal(goal, false)); // duplicate ID
        QVERIFY(repository.loadTransactions().isEmpty());
    }
    {
        FinanceRepository repository(path);
        const auto loaded = repository.loadFinancialGoals();
        QCOMPARE(loaded.size(), 1);
        QCOMPARE(loaded.first().targetMinor, goal.targetMinor);
        QVERIFY(!loaded.first().deadline.isValid());
        goal.name = QStringLiteral("Updated"); goal.currency = Currency::EUR;
        goal.deadline = QDate(2027, 5, 20); goal.targetMinor = 30'000'000;
        goal.allSources = false;
        goal.sourceIds = {QStringLiteral("account:household-rub")};
        QVERIFY(repository.saveFinancialGoal(goal, true));
    }
    {
        FinanceRepository repository(path);
        const auto loaded = repository.loadFinancialGoals().first();
        QCOMPARE(loaded.name, goal.name);
        QCOMPARE(loaded.currency, Currency::EUR);
        QCOMPARE(loaded.deadline, goal.deadline);
        QCOMPARE(loaded.sourceIds, goal.sourceIds);
        QVERIFY(!loaded.allSources);
        QVERIFY(repository.deleteFinancialGoal(goal.id));
        QVERIFY(repository.loadFinancialGoals().isEmpty());
        QVERIFY(!repository.deleteFinancialGoal(goal.id));
        QVERIFY(!repository.saveFinancialGoal(goal, true));
        QVERIFY(repository.loadTransactions().isEmpty());
        QVERIFY(!repository.loadAccounts().isEmpty());
    }
}

void FinanceRepositoryTest::migratesLegacyProjectTable()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-project-table-migration.sqlite3"));
    const QString connectionName = QStringLiteral("project-table-migration-") +
        QUuid::createUuid().toString(QUuid::WithoutBraces);

    {
        QSqlDatabase database = QSqlDatabase::addDatabase(
            QStringLiteral("QSQLITE"), connectionName);
        database.setDatabaseName(databasePath);
        QVERIFY(database.open());
        QSqlQuery query(database);
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE projects(id TEXT PRIMARY KEY, name TEXT NOT NULL)")));
        QVERIFY(query.exec(QStringLiteral(
            "INSERT INTO projects(id, name) VALUES('legacy', 'Legacy')")));
        database.close();
    }
    QSqlDatabase::removeDatabase(connectionName);

    FinanceRepository repository(databasePath);
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
    const QVector<Project> projects = repository.loadProjects();
    QCOMPARE(projects.size(), 1);
    QCOMPARE(projects.constFirst().id(), QStringLiteral("legacy"));
    QVERIFY(repository.archiveProject(QStringLiteral("legacy")));
    QVERIFY(repository.loadProjects().isEmpty());
}

void FinanceRepositoryTest::storesUpdatesAndArchivesBudgets()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-budgets-test.sqlite3"));
    FinanceRepository repository(databasePath);
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account firstAccount(
        QStringLiteral("budget-card"), QStringLiteral("Card"),
        AssetType::Fiat, AccountType::DebitCard, Currency::RUB);
    const Account secondAccount(
        QStringLiteral("budget-cash"), QStringLiteral("Cash"),
        AssetType::Fiat, AccountType::Cash, Currency::USD);
    const Category groceries(
        QStringLiteral("budget-groceries"), QStringLiteral("Groceries"),
        CategoryType::Expense);
    QVERIFY(repository.insertAccount(firstAccount));
    QVERIFY(repository.insertAccount(secondAccount));
    QVERIFY(repository.insertCategory(groceries));

    const Budget created(
        QStringLiteral("household-budget"), QStringLiteral("Household"),
        Currency::RUB, 100'000'00, false, false,
        {firstAccount.id()}, {{groceries.id(), 25'000'00}},
        QDate(2026, 9, 1));
    QVERIFY2(repository.insertBudget(created, QDate(2026, 9, 1)),
             qPrintable(repository.lastError()));

    QVector<Budget> budgets = repository.loadBudgets();
    QCOMPARE(budgets.size(), 1);
    QCOMPARE(budgets.constFirst().name(), QStringLiteral("Household"));
    QCOMPARE(budgets.constFirst().accountIds(), QStringList{firstAccount.id()});
    QCOMPARE(budgets.constFirst().categoryLimits().size(), 1);
    QCOMPARE(repository.loadBudgetLimit(
        created.id(), QDate(2026, 9, 1), 0), qint64(100'000'00));

    QVERIFY(repository.ensureBudgetMonth(
        created.id(), QDate(2026, 10, 1), created.defaultLimitMinor()));
    QCOMPARE(repository.loadBudgetLimit(
        created.id(), QDate(2026, 10, 1), 0), qint64(100'000'00));

    const Budget updated(
        created.id(), QStringLiteral("Family"), Currency::USD,
        1'500'00, true, true, {}, {{groceries.id(), 500'00}},
        created.startsOn());
    QVERIFY2(repository.updateBudget(updated, QDate(2026, 10, 1)),
             qPrintable(repository.lastError()));
    budgets = repository.loadBudgets();
    QCOMPARE(budgets.constFirst().name(), QStringLiteral("Family"));
    QVERIFY(budgets.constFirst().allAccounts());
    QVERIFY(budgets.constFirst().allCategories());
    QVERIFY(budgets.constFirst().accountIds().isEmpty());
    QCOMPARE(repository.loadBudgetLimit(
        created.id(), QDate(2026, 9, 1), 0), qint64(100'000'00));
    QCOMPARE(repository.loadBudgetLimit(
        created.id(), QDate(2026, 10, 1), 0), qint64(1'500'00));

    QVERIFY(repository.archiveBudget(created.id()));
    QVERIFY(repository.loadBudgets().isEmpty());
}

void FinanceRepositoryTest::migratesProjectAssignmentForExistingDatabase()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-project-migration.sqlite3"));
    const QString connectionName = QStringLiteral("project-migration-") +
        QUuid::createUuid().toString(QUuid::WithoutBraces);

    {
        QSqlDatabase database = QSqlDatabase::addDatabase(
            QStringLiteral("QSQLITE"), connectionName);
        database.setDatabaseName(databasePath);
        QVERIFY(database.open());
        QSqlQuery query(database);
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE accounts("
            "id TEXT PRIMARY KEY, name TEXT NOT NULL, "
            "asset_type INTEGER NOT NULL CHECK(asset_type IN (0,1,2)), "
            "account_type INTEGER NOT NULL "
            "CHECK(account_type IN (0,1,2,3,4,5,6,7)), "
            "currency TEXT NOT NULL CHECK(currency IN ('RUB','USD','EUR')), "
            "initial_balance_minor INTEGER NOT NULL DEFAULT 0, "
            "credit_limit_minor INTEGER NOT NULL DEFAULT 0, "
            "is_archived INTEGER NOT NULL DEFAULT 0, "
            "created_at INTEGER NOT NULL)")));
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE categories("
            "id TEXT PRIMARY KEY, name TEXT NOT NULL, type INTEGER NOT NULL, "
            "is_system INTEGER NOT NULL DEFAULT 0, "
            "is_archived INTEGER NOT NULL DEFAULT 0, "
            "created_at INTEGER NOT NULL)")));
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE transactions("
            "id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id), "
            "category_id TEXT NOT NULL REFERENCES categories(id), "
            "type INTEGER NOT NULL CHECK(type IN (0,1)), "
            "amount_minor INTEGER NOT NULL CHECK(amount_minor > 0), "
            "occurred_at INTEGER NOT NULL, description TEXT NOT NULL DEFAULT '', "
            "created_at INTEGER NOT NULL)")));
        QVERIFY(query.exec(QStringLiteral(
            "INSERT INTO accounts VALUES("
            "'legacy-account','Legacy',0,1,'RUB',0,0,0,1)")));
        QVERIFY(query.exec(QStringLiteral(
            "INSERT INTO categories VALUES("
            "'legacy-expense','Legacy expense',1,0,0,1)")));
        QVERIFY(query.exec(QStringLiteral(
            "INSERT INTO transactions VALUES("
            "'legacy-operation','legacy-account','legacy-expense',1,1000,1,'',1)")));
        database.close();
    }
    QSqlDatabase::removeDatabase(connectionName);

    FinanceRepository repository(databasePath);
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
    const QVector<Transaction> transactions = repository.loadTransactions();
    QCOMPARE(transactions.size(), 1);
    QVERIFY(transactions.constFirst().projectId().isEmpty());

    const Project project(
        QStringLiteral("migrated-project"),
        QStringLiteral("Migrated project"));
    QVERIFY(repository.insertProject(project));
    const Transaction assigned(
        transactions.constFirst().id(),
        transactions.constFirst().accountId(),
        transactions.constFirst().categoryId(),
        transactions.constFirst().money(),
        transactions.constFirst().type(),
        transactions.constFirst().date(),
        transactions.constFirst().description(),
        project.id());
    QVERIFY2(repository.updateTransaction(assigned),
             qPrintable(repository.lastError()));
    QCOMPARE(repository.loadTransactions().constFirst().projectId(), project.id());
}

void FinanceRepositoryTest::storesProjectsAndTransactionAssignments()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-projects-test.sqlite3"));

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

        const Account account(
            QStringLiteral("project-account"),
            QStringLiteral("Project card"),
            AssetType::Fiat,
            AccountType::DebitCard,
            Currency::RUB);
        const Category incomeCategory(
            QStringLiteral("project-income"),
            QStringLiteral("Project income"),
            CategoryType::Income);
        const Category expenseCategory(
            QStringLiteral("project-expense"),
            QStringLiteral("Project expense"),
            CategoryType::Expense);
        const Project firstProject(
            QStringLiteral("moneytracker"),
            QStringLiteral("MoneyTracker"));
        const Project secondProject(
            QStringLiteral("proxy"),
            QStringLiteral("Proxy"));

        QVERIFY(repository.insertAccount(account));
        QVERIFY(repository.insertCategory(incomeCategory));
        QVERIFY(repository.insertCategory(expenseCategory));
        QVERIFY(repository.insertProject(firstProject));
        QVERIFY(repository.insertProject(secondProject));
        QVERIFY(repository.insertTransaction(Transaction(
            QStringLiteral("project-income-operation"),
            account.id(),
            incomeCategory.id(),
            Money(100'000, Currency::RUB),
            TransactionType::Income,
            QDateTime::currentDateTimeUtc(),
            QStringLiteral("First customer"),
            firstProject.id())));
        QVERIFY(repository.insertTransaction(Transaction(
            QStringLiteral("project-expense-operation"),
            account.id(),
            expenseCategory.id(),
            Money(2'600, Currency::RUB),
            TransactionType::Expense,
            QDateTime::currentDateTimeUtc(),
            QStringLiteral("ChatGPT"),
            firstProject.id())));

        const QVector<Project> projects = repository.loadProjects();
        QCOMPARE(projects.size(), 2);
        const QVector<Transaction> transactions =
            repository.loadTransactions();
        QCOMPARE(transactions.size(), 2);
        QCOMPARE(transactions.at(0).projectId(), firstProject.id());
        QCOMPARE(transactions.at(1).projectId(), firstProject.id());

        QVERIFY(repository.updateProject(Project(
            firstProject.id(), QStringLiteral("Ledgera"))));
        QVERIFY(repository.archiveProject(secondProject.id()));
        const QVector<Project> activeProjects = repository.loadProjects();
        QCOMPARE(activeProjects.size(), 1);
        QCOMPARE(activeProjects.constFirst().id(), firstProject.id());
        QCOMPARE(activeProjects.constFirst().name(), QStringLiteral("Ledgera"));
    }

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        QCOMPARE(repository.loadProjects().size(), 1);
        const QVector<Transaction> transactions =
            repository.loadTransactions();
        QCOMPARE(transactions.size(), 2);
        for (const Transaction& transaction : transactions) {
            QCOMPARE(transaction.projectId(), QStringLiteral("moneytracker"));
        }
    }
}

void FinanceRepositoryTest::storesAndMaterializesRecurringTransactions()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    FinanceRepository repository(temporaryDirectory.filePath(
        QStringLiteral("moneytracker-recurring-test.sqlite3")));
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account account(
        QStringLiteral("recurring-account"),
        QStringLiteral("Main account"),
        AssetType::Fiat,
        AccountType::DebitCard,
        Currency::RUB);
    const Category category(
        QStringLiteral("recurring-category"),
        QStringLiteral("Rent"),
        CategoryType::Expense);
    QVERIFY(repository.insertAccount(account));
    QVERIFY(repository.insertCategory(category));

    const RecurringTransaction schedule(
        QStringLiteral("rent-schedule"),
        QStringLiteral("Rent"),
        account.id(),
        category.id(),
        TransactionType::Expense,
        50'000,
        Currency::USD,
        RecurrenceType::Weekly,
        4,
        1,
        1,
        QDate(2026, 9, 1),
        QDate(2026, 8, 31));
    QVERIFY2(repository.insertRecurringTransaction(schedule),
             qPrintable(repository.lastError()));

    const auto makeOccurrence = [&account, &category](
        const QString& id,
        const QDate& date
        )
    {
        return FinanceRepository::RecurringOccurrence{
            date,
            Transaction(
                id,
                account.id(),
                category.id(),
                Money(50'000, Currency::RUB),
                TransactionType::Expense,
                QDateTime(date, QTime(12, 0), QTimeZone::UTC),
                QStringLiteral("Rent"))};
    };
    const QVector<FinanceRepository::RecurringOccurrence> occurrences{
        makeOccurrence(QStringLiteral("rent-20260903"), QDate(2026, 9, 3)),
        makeOccurrence(QStringLiteral("rent-20260910"), QDate(2026, 9, 10))};
    int inserted = -1;
    QVERIFY2(repository.materializeRecurringOccurrences(
                 schedule.id(), occurrences, QDate(2026, 9, 10), &inserted),
             qPrintable(repository.lastError()));
    QCOMPARE(inserted, 2);
    QCOMPARE(repository.loadTransactions().size(), 2);

    QVERIFY2(repository.materializeRecurringOccurrences(
                 schedule.id(), occurrences, QDate(2026, 9, 10), &inserted),
             qPrintable(repository.lastError()));
    QCOMPARE(inserted, 0);
    QCOMPARE(repository.loadTransactions().size(), 2);

    QVector<RecurringTransaction> restored =
        repository.loadRecurringTransactions();
    QCOMPARE(restored.size(), 1);
    QCOMPARE(restored.constFirst().currency(), Currency::USD);
    QCOMPARE(restored.constFirst().generatedThrough(), QDate(2026, 9, 10));

    const RecurringTransaction updated(
        schedule.id(),
        QStringLiteral("Updated rent"),
        account.id(),
        category.id(),
        TransactionType::Expense,
        75'000,
        Currency::EUR,
        RecurrenceType::MonthlyDay,
        1,
        15,
        1,
        QDate(2026, 9, 1),
        restored.constFirst().generatedThrough());
    QVERIFY2(repository.updateRecurringTransaction(updated),
             qPrintable(repository.lastError()));
    restored = repository.loadRecurringTransactions();
    QCOMPARE(restored.constFirst().name(), QStringLiteral("Updated rent"));
    QCOMPARE(restored.constFirst().amountMinor(), qint64(75'000));
    QCOMPARE(restored.constFirst().currency(), Currency::EUR);
    QVERIFY(restored.constFirst().recurrenceType() ==
            RecurrenceType::MonthlyDay);
    QCOMPARE(restored.constFirst().generatedThrough(), QDate(2026, 9, 10));

    QVERIFY(repository.deleteRecurringTransaction(schedule.id()));
    QVERIFY(repository.loadRecurringTransactions().isEmpty());
    QCOMPARE(repository.loadTransactions().size(), 2);
}

void FinanceRepositoryTest::storesBankCsvProfiles()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-bank-csv-profile-test.sqlite3"));

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        QVERIFY2(repository.saveBankCsvProfile(
                     QStringLiteral("alpha"),
                     QStringLiteral("Альфа-Банк"),
                     QStringLiteral("{\"dateColumn\":0}")),
                 qPrintable(repository.lastError()));
        QVERIFY2(repository.saveBankCsvProfile(
                     QStringLiteral("alpha"),
                     QStringLiteral("Альфа-Банк обновлённый"),
                     QStringLiteral("{\"dateColumn\":2}")),
                 qPrintable(repository.lastError()));
    }

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        const auto profiles = repository.loadBankCsvProfiles();
        QCOMPARE(profiles.size(), 1);
        QCOMPARE(profiles.constFirst().id, QStringLiteral("alpha"));
        QCOMPARE(profiles.constFirst().name,
                 QStringLiteral("Альфа-Банк обновлённый"));
        QCOMPARE(profiles.constFirst().configurationJson,
                 QStringLiteral("{\"dateColumn\":2}"));
        QVERIFY(repository.deleteBankCsvProfile(QStringLiteral("alpha")));
        QVERIFY(repository.loadBankCsvProfiles().isEmpty());
    }
}

void FinanceRepositoryTest::storesCryptoWalletAndPriceSnapshots()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-crypto-test.sqlite3"));
    const QDateTime balanceFetchedAt = QDateTime::fromMSecsSinceEpoch(
        1'788'100'000'000, QTimeZone::UTC);
    const QDateTime priceFetchedAt = balanceFetchedAt.addSecs(2);

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        const CryptoWallet wallet(
            QStringLiteral("tron-wallet"),
            QStringLiteral("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"));
        QVERIFY2(repository.insertCryptoWallet(wallet),
                 qPrintable(repository.lastError()));
        QVERIFY2(repository.updateCryptoWalletBalance(
                     wallet.id(), 12'345'678, balanceFetchedAt),
                 qPrintable(repository.lastError()));
        QVERIFY2(repository.saveCryptoPrice(
                     QStringLiteral("USDT"), 999'731, priceFetchedAt),
                 qPrintable(repository.lastError()));
        QVERIFY2(repository.saveCryptoPrice(
                     QStringLiteral("BTC"), 112'345'000'000, priceFetchedAt),
                 qPrintable(repository.lastError()));
        QVERIFY2(repository.saveCryptoRefreshAttemptUtc(priceFetchedAt),
                 qPrintable(repository.lastError()));
        const QVector<CryptoTransaction> transactions{
            CryptoTransaction(
                wallet.id(),
                QStringLiteral("transaction-in"),
                QStringLiteral("TUoHaVjx7n5xz8LwPRDckgFrDWhMhuSuJM"),
                wallet.address(),
                120'650'000,
                balanceFetchedAt.addDays(-1)),
            CryptoTransaction(
                wallet.id(),
                QStringLiteral("transaction-out"),
                wallet.address(),
                QStringLiteral("TUoHaVjx7n5xz8LwPRDckgFrDWhMhuSuJM"),
                11'518'000,
                balanceFetchedAt.addDays(-2))};
        QVERIFY2(repository.replaceCryptoTransactions(
                     wallet.id(), transactions, priceFetchedAt),
                 qPrintable(repository.lastError()));
    }

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        const QVector<CryptoWallet> wallets = repository.loadCryptoWallets();
        QCOMPARE(wallets.size(), 1);
        QCOMPARE(wallets.constFirst().id(), QStringLiteral("tron-wallet"));
        QCOMPARE(wallets.constFirst().balanceAtomic(), qint64(12'345'678));
        QCOMPARE(wallets.constFirst().balanceFetchedAtUtc(), balanceFetchedAt);
        QCOMPARE(wallets.constFirst().historyFetchedAtUtc(), priceFetchedAt);

        const QVector<CryptoTransaction> transactions =
            repository.loadCryptoTransactions();
        QCOMPARE(transactions.size(), 2);
        QCOMPARE(
            transactions.constFirst().transactionId(),
            QStringLiteral("transaction-in"));
        QCOMPARE(transactions.constFirst().amountAtomic(), qint64(120'650'000));

        const FinanceRepository::CryptoPriceSnapshot price =
            repository.loadCryptoPrice(QStringLiteral("USDT"));
        QCOMPARE(price.priceUsdMicros, qint64(999'731));
        QCOMPARE(price.fetchedAtUtc, priceFetchedAt);
        QCOMPARE(
            repository.loadCryptoPrice(QStringLiteral("BTC")).priceUsdMicros,
            qint64(112'345'000'000));
        QCOMPARE(repository.loadCryptoRefreshAttemptUtc(), priceFetchedAt);

        QVERIFY2(repository.deleteCryptoWallet(QStringLiteral("tron-wallet")),
                 qPrintable(repository.lastError()));
        QVERIFY(repository.loadCryptoWallets().isEmpty());
        QVERIFY(repository.loadCryptoTransactions().isEmpty());

        const CryptoWallet replacement(
            QStringLiteral("tron-wallet-replacement"),
            QStringLiteral("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"));
        QVERIFY2(repository.insertCryptoWallet(replacement),
                 qPrintable(repository.lastError()));
    }
}

void FinanceRepositoryTest::migratesLegacyCryptoSchema()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-crypto-migration.sqlite3"));
    const QString connectionName = QStringLiteral("crypto-migration-")
        + QUuid::createUuid().toString(QUuid::WithoutBraces);

    {
        QSqlDatabase database = QSqlDatabase::addDatabase(
            QStringLiteral("QSQLITE"), connectionName);
        database.setDatabaseName(databasePath);
        QVERIFY(database.open());
        QSqlQuery query(database);
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE crypto_wallets ("
            "id TEXT PRIMARY KEY, address TEXT NOT NULL, "
            "network TEXT NOT NULL CHECK(network = 'TRON'), "
            "symbol TEXT NOT NULL CHECK(symbol = 'USDT'), "
            "balance_atomic INTEGER NOT NULL DEFAULT 0, "
            "balance_fetched_at INTEGER, history_fetched_at INTEGER, "
            "is_archived INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)")));
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE crypto_transactions ("
            "wallet_id TEXT NOT NULL REFERENCES crypto_wallets(id), "
            "transaction_id TEXT NOT NULL, from_address TEXT NOT NULL, "
            "to_address TEXT NOT NULL, amount_atomic INTEGER NOT NULL, "
            "occurred_at INTEGER NOT NULL, PRIMARY KEY(wallet_id, transaction_id))")));
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE crypto_prices ("
            "symbol TEXT PRIMARY KEY CHECK(symbol = 'USDT'), "
            "price_usd_micros INTEGER NOT NULL, fetched_at INTEGER NOT NULL)")));
        QVERIFY(query.exec(QStringLiteral(
            "INSERT INTO crypto_wallets VALUES("
            "'legacy-wallet','TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',"
            "'TRON','USDT',12345678,1000,2000,0,1)")));
        QVERIFY(query.exec(QStringLiteral(
            "INSERT INTO crypto_prices VALUES('USDT',999731,3000)")));
        database.close();
    }
    QSqlDatabase::removeDatabase(connectionName);

    FinanceRepository repository(databasePath);
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
    const QVector<CryptoWallet> wallets = repository.loadCryptoWallets();
    QCOMPARE(wallets.size(), 1);
    QCOMPARE(wallets.constFirst().symbol(), QStringLiteral("USDT"));
    QCOMPARE(wallets.constFirst().network(), QStringLiteral("TRON"));
    QCOMPARE(wallets.constFirst().decimals(), 6);
    QCOMPARE(wallets.constFirst().balanceAtomic(), qint64(12'345'678));

    const CryptoWallet bitcoin(
        QStringLiteral("btc-wallet"),
        QStringLiteral("1BoatSLRHtKNngkdXEeobR76b53LETtpyT"),
        QStringLiteral("BITCOIN"),
        QStringLiteral("BTC"),
        8);
    const CryptoWallet ethereum(
        QStringLiteral("eth-wallet"),
        QStringLiteral("0xd8da6bf26964af9d7eed9e03e53415d37aa96045"),
        QStringLiteral("ETHEREUM"),
        QStringLiteral("ETH"),
        8);
    QVERIFY2(repository.insertCryptoWallet(bitcoin),
             qPrintable(repository.lastError()));
    QVERIFY2(repository.insertCryptoWallet(ethereum),
             qPrintable(repository.lastError()));
    QCOMPARE(repository.loadCryptoWallets().size(), 3);
    QVERIFY2(repository.saveCryptoPrice(
                 QStringLiteral("ETH"), 4'567'000'000, QDateTime::currentDateTimeUtc()),
             qPrintable(repository.lastError()));
}

void FinanceRepositoryTest::storesCurrencyRateSettings()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-rate-settings-test.sqlite3"));

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        QVERIFY(repository.loadAutomaticCurrencyRates());
        QVERIFY(repository.saveAutomaticCurrencyRates(false));
        QVERIFY(repository.saveManualCurrencyRates(1.02, 86.54, 100.12));
    }

    FinanceRepository reopened(databasePath);
    QVERIFY2(reopened.isOpen(), qPrintable(reopened.lastError()));
    QVERIFY(!reopened.loadAutomaticCurrencyRates());
    QCOMPARE(reopened.loadManualRubToRubRate(), 1.02);
    QCOMPARE(reopened.loadManualUsdToRubRate(), 86.54);
    QCOMPARE(reopened.loadManualEurToRubRate(), 100.12);
}

void FinanceRepositoryTest::storesCreditCardTerms()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    FinanceRepository repository(temporaryDirectory.filePath(
        QStringLiteral("moneytracker-credit-card-test.sqlite3")));
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account creditCard(
        QStringLiteral("credit-card"),
        QStringLiteral("Credit card"),
        AssetType::Fiat,
        AccountType::CreditCard,
        Currency::RUB,
        -5'000,
        85'000);
    QVERIFY2(repository.insertAccount(creditCard),
             qPrintable(repository.lastError()));

    const QVector<Account> accounts = repository.loadAccounts();
    bool restored = false;
    for (const Account& account : accounts) {
        if (account.id() != creditCard.id()) {
            continue;
        }
        restored = true;
        QCOMPARE(account.type(), AccountType::CreditCard);
        QCOMPARE(account.initialBalanceMinor(), qint64(-5'000));
        QCOMPARE(account.creditLimitMinor(), qint64(85'000));
        QCOMPARE(account.debtMinor(-5'000), qint64(5'000));
        QCOMPARE(account.availableCreditMinor(-5'000), qint64(80'000));
        QCOMPARE(account.debtMinor(0), qint64(0));
        QCOMPARE(account.availableCreditMinor(0), qint64(85'000));
        QCOMPARE(account.availableCreditMinor(2'000), qint64(87'000));
    }
    QVERIFY(restored);

    const FinanceRepository::Summary summary = repository.loadSummary();
    QCOMPARE(summary.balance[static_cast<int>(Currency::RUB)], qint64(-5'000));
}

void FinanceRepositoryTest::migratesCreditLimitForExistingDatabase()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-credit-limit-migration.sqlite3"));
    const QString connectionName = QStringLiteral("credit-limit-migration-")
        + QUuid::createUuid().toString(QUuid::WithoutBraces);

    {
        QSqlDatabase database = QSqlDatabase::addDatabase(
            QStringLiteral("QSQLITE"), connectionName);
        database.setDatabaseName(databasePath);
        QVERIFY(database.open());
        QSqlQuery query(database);
        QVERIFY2(query.exec(QStringLiteral(
            "CREATE TABLE accounts ("
            "id TEXT PRIMARY KEY, name TEXT NOT NULL, "
            "asset_type INTEGER NOT NULL, account_type INTEGER NOT NULL, "
            "currency TEXT NOT NULL, initial_balance_minor INTEGER NOT NULL DEFAULT 0, "
            "is_archived INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)")),
            qPrintable(query.lastError().text()));
        QVERIFY2(query.exec(QStringLiteral(
            "INSERT INTO accounts(id, name, asset_type, account_type, currency, "
            "initial_balance_minor, is_archived, created_at) "
            "VALUES('legacy-credit-card', 'Legacy card', 0, 2, 'RUB', -5000, 0, 1)")),
            qPrintable(query.lastError().text()));
        QVERIFY2(query.exec(QStringLiteral(
            "INSERT INTO accounts(id, name, asset_type, account_type, currency, "
            "initial_balance_minor, is_archived, created_at) "
            "VALUES('legacy-credit-limit', 'Legacy limit', 0, 2, 'RUB', 85000, 0, 2)")),
            qPrintable(query.lastError().text()));
        database.close();
    }
    QSqlDatabase::removeDatabase(connectionName);

    FinanceRepository repository(databasePath);
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
    const QVector<Account> accounts = repository.loadAccounts();
    bool restoredDebt = false;
    bool restoredLimit = false;
    for (const Account& account : accounts) {
        if (account.id() == QStringLiteral("legacy-credit-card")) {
            restoredDebt = true;
            QCOMPARE(account.initialBalanceMinor(), qint64(-5'000));
            QCOMPARE(account.creditLimitMinor(), qint64(0));
        } else if (account.id() == QStringLiteral("legacy-credit-limit")) {
            restoredLimit = true;
            QCOMPARE(account.initialBalanceMinor(), qint64(0));
            QCOMPARE(account.creditLimitMinor(), qint64(85'000));
        }
    }
    QVERIFY(restoredDebt);
    QVERIFY(restoredLimit);
}

void FinanceRepositoryTest::storesUiLanguage()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-language-test.sqlite3"));

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        QCOMPARE(repository.loadUiLanguage(), QStringLiteral("ru"));
        QVERIFY2(repository.saveUiLanguage(QStringLiteral("en")),
                 qPrintable(repository.lastError()));
    }

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        QCOMPARE(repository.loadUiLanguage(), QStringLiteral("en"));
    }
}

void FinanceRepositoryTest::preservesSelectedAccountAfterReopen()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());

    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-test.sqlite3")
    );
    const QString accountId = QStringLiteral("test-debit-card");
    const QString categoryId = QStringLiteral("test-groceries");
    const QString transactionId = QStringLiteral("test-transaction");
    const QDateTime occurredAt = QDateTime::fromMSecsSinceEpoch(
        1'788'000'000'000,
        QTimeZone::UTC
    );

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

        const Account account(
            accountId,
            QStringLiteral("Test debit card"),
            AssetType::Fiat,
            AccountType::DebitCard,
            Currency::RUB
        );
        const Category category(
            categoryId,
            QStringLiteral("Test groceries"),
            CategoryType::Expense
        );
        const Transaction transaction(
            transactionId,
            accountId,
            categoryId,
            Money(12'345, Currency::RUB),
            TransactionType::Expense,
            occurredAt,
            QStringLiteral("Test purchase")
        );

        QVERIFY2(repository.insertAccount(account),
                 qPrintable(repository.lastError()));
        QVERIFY2(repository.insertCategory(category),
                 qPrintable(repository.lastError()));
        QVERIFY2(repository.insertTransaction(transaction),
                 qPrintable(repository.lastError()));
    }

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

        const QVector<Transaction> transactions = repository.loadTransactions();
        QCOMPARE(transactions.size(), 1);

        const Transaction& restored = transactions.constFirst();
        QCOMPARE(restored.id(), transactionId);
        QCOMPARE(restored.accountId(), accountId);
        QCOMPARE(restored.categoryId(), categoryId);
        QCOMPARE(restored.money().minorUnits(), qint64(12'345));
        QCOMPARE(restored.money().currency(), Currency::RUB);
        QCOMPARE(restored.type(), TransactionType::Expense);
        QCOMPARE(restored.date(), occurredAt);
        QCOMPARE(restored.description(), QStringLiteral("Test purchase"));
    }
}

void FinanceRepositoryTest::updatesAndDeletesTransaction()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());

    FinanceRepository repository(
        temporaryDirectory.filePath(QStringLiteral("moneytracker-edit-test.sqlite3"))
    );
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account rubAccount(
        QStringLiteral("edit-rub-account"),
        QStringLiteral("RUB account"),
        AssetType::Fiat,
        AccountType::DebitCard,
        Currency::RUB
    );
    const Account usdAccount(
        QStringLiteral("edit-usd-account"),
        QStringLiteral("USD account"),
        AssetType::Fiat,
        AccountType::DebitCard,
        Currency::USD
    );
    const Category expenseCategory(
        QStringLiteral("edit-expense-category"),
        QStringLiteral("Expense"),
        CategoryType::Expense
    );
    const Category incomeCategory(
        QStringLiteral("edit-income-category"),
        QStringLiteral("Income"),
        CategoryType::Income
    );
    const QDateTime originalDate = QDateTime::fromMSecsSinceEpoch(
        1'788'000'000'000,
        QTimeZone::UTC
    );
    const QDateTime updatedDate = originalDate.addDays(1);

    QVERIFY(repository.insertAccount(rubAccount));
    QVERIFY(repository.insertAccount(usdAccount));
    QVERIFY(repository.insertCategory(expenseCategory));
    QVERIFY(repository.insertCategory(incomeCategory));
    QVERIFY(repository.insertTransaction(Transaction(
        QStringLiteral("editable-transaction"),
        rubAccount.id(),
        expenseCategory.id(),
        Money(12'345, Currency::RUB),
        TransactionType::Expense,
        originalDate,
        QStringLiteral("Before edit")
    )));

    const Transaction updated(
        QStringLiteral("editable-transaction"),
        usdAccount.id(),
        incomeCategory.id(),
        Money(98'765, Currency::USD),
        TransactionType::Income,
        updatedDate,
        QStringLiteral("After edit")
    );
    QVERIFY2(repository.updateTransaction(updated),
             qPrintable(repository.lastError()));

    const QVector<Transaction> transactions = repository.loadTransactions();
    QCOMPARE(transactions.size(), 1);
    const Transaction& restored = transactions.constFirst();
    QCOMPARE(restored.id(), updated.id());
    QCOMPARE(restored.accountId(), usdAccount.id());
    QCOMPARE(restored.categoryId(), incomeCategory.id());
    QCOMPARE(restored.money().minorUnits(), qint64(98'765));
    QCOMPARE(restored.money().currency(), Currency::USD);
    QCOMPARE(restored.type(), TransactionType::Income);
    QCOMPARE(restored.date(), updatedDate);
    QCOMPARE(restored.description(), QStringLiteral("After edit"));

    const FinanceRepository::Summary updatedSummary = repository.loadSummary();
    QCOMPARE(updatedSummary.income[static_cast<int>(Currency::USD)], qint64(98'765));
    QCOMPARE(updatedSummary.expense[static_cast<int>(Currency::RUB)], qint64(0));
    QCOMPARE(updatedSummary.balance[static_cast<int>(Currency::USD)], qint64(98'765));

    QVERIFY2(repository.deleteTransaction(updated.id()),
             qPrintable(repository.lastError()));
    QVERIFY(repository.loadTransactions().isEmpty());

    const FinanceRepository::Summary deletedSummary = repository.loadSummary();
    QCOMPARE(deletedSummary.income[static_cast<int>(Currency::USD)], qint64(0));
    QCOMPARE(deletedSummary.balance[static_cast<int>(Currency::USD)], qint64(0));
}

void FinanceRepositoryTest::storesTransferAtomicallyWithoutAffectingIncomeAndExpense()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    FinanceRepository repository(
        temporaryDirectory.filePath(QStringLiteral("moneytracker-transfer-test.sqlite3")));
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account source(
        QStringLiteral("source-account"), QStringLiteral("Source"),
        AssetType::Fiat, AccountType::DebitCard, Currency::RUB, 50'000);
    const Account target(
        QStringLiteral("target-account"), QStringLiteral("Target"),
        AssetType::Crypto, AccountType::CryptoWallet, Currency::USD, 0);
    QVERIFY(repository.insertAccount(source));
    QVERIFY(repository.insertAccount(target));

    const QDateTime occurredAt = QDateTime::currentDateTimeUtc();
    const Transaction outgoing(
        QStringLiteral("transfer-id-out"), source.id(), QStringLiteral("transfer-out"),
        Money(10'000, Currency::RUB), TransactionType::Expense,
        occurredAt, QStringLiteral("Transfer test"));
    const Transaction incoming(
        QStringLiteral("transfer-id-in"), target.id(), QStringLiteral("transfer-in"),
        Money(125, Currency::USD), TransactionType::Income,
        occurredAt, QStringLiteral("Transfer test"));

    const Transaction invalidIncoming(
        QStringLiteral("invalid-transfer-in"), QStringLiteral("missing-account"),
        QStringLiteral("transfer-in"), Money(125, Currency::USD),
        TransactionType::Income, occurredAt, QStringLiteral("Invalid transfer"));
    QVERIFY(!repository.insertTransfer(outgoing, invalidIncoming));
    QVERIFY(repository.loadTransactions().isEmpty());

    QVERIFY2(repository.insertTransfer(outgoing, incoming),
             qPrintable(repository.lastError()));
    QCOMPARE(repository.loadTransactions().size(), 2);

    const FinanceRepository::Summary summary = repository.loadSummary();
    QCOMPARE(summary.balance[static_cast<int>(Currency::RUB)], qint64(40'000));
    QCOMPARE(summary.balance[static_cast<int>(Currency::USD)], qint64(125));
    QCOMPARE(summary.income[static_cast<int>(Currency::USD)], qint64(0));
    QCOMPARE(summary.expense[static_cast<int>(Currency::RUB)], qint64(0));
}

void FinanceRepositoryTest::replacesIncomeWithTransferAtomically()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    FinanceRepository repository(temporaryDirectory.filePath(
        QStringLiteral("moneytracker-convert-to-transfer-test.sqlite3")));
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account source(
        QStringLiteral("convert-source"), QStringLiteral("Source"),
        AssetType::Fiat, AccountType::DebitCard, Currency::RUB, 50'000);
    const Account target(
        QStringLiteral("convert-target"), QStringLiteral("Target"),
        AssetType::Crypto, AccountType::CryptoWallet, Currency::USD, 0);
    const Category incomeCategory(
        QStringLiteral("convert-income"), QStringLiteral("Income"),
        CategoryType::Income);
    QVERIFY(repository.insertAccount(source));
    QVERIFY(repository.insertAccount(target));
    QVERIFY(repository.insertCategory(incomeCategory));

    const QDateTime occurredAt = QDateTime::currentDateTimeUtc();
    const Transaction income(
        QStringLiteral("income-to-convert"), source.id(), incomeCategory.id(),
        Money(1'000, Currency::RUB), TransactionType::Income,
        occurredAt, QStringLiteral("Income"));
    QVERIFY(repository.insertTransaction(income));

    const Transaction outgoing(
        QStringLiteral("converted-transfer-out"), source.id(),
        QStringLiteral("transfer-out"), Money(10'000, Currency::RUB),
        TransactionType::Expense, occurredAt, QStringLiteral("Converted"));
    const Transaction incoming(
        QStringLiteral("converted-transfer-in"), target.id(),
        QStringLiteral("transfer-in"), Money(125, Currency::USD),
        TransactionType::Income, occurredAt, QStringLiteral("Converted"));
    const Transaction invalidIncoming(
        QStringLiteral("converted-transfer-in"), QStringLiteral("missing-account"),
        QStringLiteral("transfer-in"), Money(125, Currency::USD),
        TransactionType::Income, occurredAt, QStringLiteral("Invalid"));

    QVERIFY(!repository.replaceTransactionWithTransfer(
        income.id(), outgoing, invalidIncoming));
    QVector<Transaction> transactions = repository.loadTransactions();
    QCOMPARE(transactions.size(), 1);
    QCOMPARE(transactions.constFirst().id(), income.id());

    QVERIFY2(repository.replaceTransactionWithTransfer(
        income.id(), outgoing, incoming), qPrintable(repository.lastError()));
    transactions = repository.loadTransactions();
    QCOMPARE(transactions.size(), 2);

    QSet<QString> ids;
    for (const Transaction& transaction : transactions) {
        ids.insert(transaction.id());
    }
    QVERIFY(ids.contains(outgoing.id()));
    QVERIFY(ids.contains(incoming.id()));
    QVERIFY(!ids.contains(income.id()));

    const FinanceRepository::Summary summary = repository.loadSummary();
    QCOMPARE(summary.balance[static_cast<int>(Currency::RUB)], qint64(40'000));
    QCOMPARE(summary.balance[static_cast<int>(Currency::USD)], qint64(125));
    QCOMPARE(summary.income[static_cast<int>(Currency::RUB)], qint64(0));
    QCOMPARE(summary.expense[static_cast<int>(Currency::RUB)], qint64(0));

    const Transaction updatedOutgoing(
        outgoing.id(), source.id(), QStringLiteral("transfer-out"),
        Money(5'000, Currency::RUB), TransactionType::Expense,
        occurredAt, QStringLiteral("Updated transfer"));
    const Transaction updatedIncoming(
        incoming.id(), target.id(), QStringLiteral("transfer-in"),
        Money(63, Currency::USD), TransactionType::Income,
        occurredAt, QStringLiteral("Updated transfer"));
    QVERIFY2(repository.replaceTransactionWithTransfer(
        incoming.id(), updatedOutgoing, updatedIncoming),
        qPrintable(repository.lastError()));

    transactions = repository.loadTransactions();
    QCOMPARE(transactions.size(), 2);
    for (const Transaction& transaction : transactions) {
        QCOMPARE(transaction.description(), QStringLiteral("Updated transfer"));
        if (transaction.categoryId() == QStringLiteral("transfer-out")) {
            QCOMPARE(transaction.money().minorUnits(), qint64(5'000));
        } else {
            QCOMPARE(transaction.categoryId(), QStringLiteral("transfer-in"));
            QCOMPARE(transaction.money().minorUnits(), qint64(63));
        }
    }

    const FinanceRepository::Summary updatedSummary = repository.loadSummary();
    QCOMPARE(updatedSummary.balance[static_cast<int>(Currency::RUB)], qint64(45'000));
    QCOMPARE(updatedSummary.balance[static_cast<int>(Currency::USD)], qint64(63));
}

void FinanceRepositoryTest::deletesWholeTransferFromEitherComponent()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    FinanceRepository repository(temporaryDirectory.filePath(
        QStringLiteral("moneytracker-delete-transfer-test.sqlite3")));
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account source(
        QStringLiteral("delete-source"), QStringLiteral("Source"),
        AssetType::Fiat, AccountType::DebitCard, Currency::RUB, 50'000);
    const Account target(
        QStringLiteral("delete-target"), QStringLiteral("Target"),
        AssetType::Fiat, AccountType::DebitCard, Currency::RUB, 0);
    QVERIFY(repository.insertAccount(source));
    QVERIFY(repository.insertAccount(target));

    const QDateTime occurredAt = QDateTime::currentDateTimeUtc();
    const auto makeOutgoing = [&](const QString& prefix) {
        return Transaction(
            prefix + QStringLiteral("-out"), source.id(),
            QStringLiteral("transfer-out"), Money(10'000, Currency::RUB),
            TransactionType::Expense, occurredAt, QStringLiteral("Transfer"));
    };
    const auto makeIncoming = [&](const QString& prefix) {
        return Transaction(
            prefix + QStringLiteral("-in"), target.id(),
            QStringLiteral("transfer-in"), Money(10'000, Currency::RUB),
            TransactionType::Income, occurredAt, QStringLiteral("Transfer"));
    };

    Transaction outgoing = makeOutgoing(QStringLiteral("delete-by-incoming"));
    Transaction incoming = makeIncoming(QStringLiteral("delete-by-incoming"));
    QVERIFY(repository.insertTransfer(outgoing, incoming));
    QVERIFY2(repository.deleteTransaction(incoming.id()),
             qPrintable(repository.lastError()));
    QVERIFY(repository.loadTransactions().isEmpty());

    outgoing = makeOutgoing(QStringLiteral("delete-by-outgoing"));
    incoming = makeIncoming(QStringLiteral("delete-by-outgoing"));
    QVERIFY(repository.insertTransfer(outgoing, incoming));
    QVERIFY2(repository.deleteTransaction(outgoing.id()),
             qPrintable(repository.lastError()));
    QVERIFY(repository.loadTransactions().isEmpty());

    const FinanceRepository::Summary summary = repository.loadSummary();
    QCOMPARE(summary.balance[static_cast<int>(Currency::RUB)], qint64(50'000));
}

void FinanceRepositoryTest::replacesTransferWithTransactionAtomically()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    FinanceRepository repository(temporaryDirectory.filePath(
        QStringLiteral("moneytracker-convert-from-transfer-test.sqlite3")));
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account source(
        QStringLiteral("replace-source"), QStringLiteral("Source"),
        AssetType::Fiat, AccountType::DebitCard, Currency::RUB, 50'000);
    const Account target(
        QStringLiteral("replace-target"), QStringLiteral("Target"),
        AssetType::Fiat, AccountType::DebitCard, Currency::RUB, 0);
    const Category expenseCategory(
        QStringLiteral("replacement-expense"), QStringLiteral("Expense"),
        CategoryType::Expense);
    QVERIFY(repository.insertAccount(source));
    QVERIFY(repository.insertAccount(target));
    QVERIFY(repository.insertCategory(expenseCategory));

    const QDateTime occurredAt = QDateTime::currentDateTimeUtc();
    const Transaction outgoing(
        QStringLiteral("replace-transfer-out"), source.id(),
        QStringLiteral("transfer-out"), Money(10'000, Currency::RUB),
        TransactionType::Expense, occurredAt, QStringLiteral("Transfer"));
    const Transaction incoming(
        QStringLiteral("replace-transfer-in"), target.id(),
        QStringLiteral("transfer-in"), Money(10'000, Currency::RUB),
        TransactionType::Income, occurredAt, QStringLiteral("Transfer"));
    QVERIFY(repository.insertTransfer(outgoing, incoming));

    const Transaction expense(
        QStringLiteral("replacement-operation"), target.id(), expenseCategory.id(),
        Money(2'500, Currency::RUB), TransactionType::Expense,
        occurredAt, QStringLiteral("Replacement"));
    QVERIFY2(repository.replaceTransaction(incoming.id(), expense),
             qPrintable(repository.lastError()));

    const QVector<Transaction> transactions = repository.loadTransactions();
    QCOMPARE(transactions.size(), 1);
    QCOMPARE(transactions.constFirst().id(), expense.id());
    QCOMPARE(transactions.constFirst().categoryId(), expenseCategory.id());

    const FinanceRepository::Summary summary = repository.loadSummary();
    QCOMPARE(summary.balance[static_cast<int>(Currency::RUB)], qint64(47'500));
    QCOMPARE(summary.expense[static_cast<int>(Currency::RUB)], qint64(2'500));
}

void FinanceRepositoryTest::updatesAccountAndProtectsTransactionCurrency()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    FinanceRepository repository(temporaryDirectory.filePath(
        QStringLiteral("moneytracker-update-account-test.sqlite3")));
    QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

    const Account original(
        QStringLiteral("editable-account"), QStringLiteral("Before"),
        AssetType::Fiat, AccountType::Cash, Currency::RUB, 10'000);
    QVERIFY(repository.insertAccount(original));

    const Account updated(
        original.id(), QStringLiteral("After"), AssetType::Fiat,
        AccountType::DebitCard, Currency::USD, 25'000);
    QVERIFY2(repository.updateAccount(updated), qPrintable(repository.lastError()));

    QVector<Account> accounts = repository.loadAccounts();
    bool foundUpdated = false;
    for (const Account& account : accounts) {
        if (account.id() != updated.id()) {
            continue;
        }
        foundUpdated = true;
        QCOMPARE(account.name(), updated.name());
        QCOMPARE(account.type(), updated.type());
        QCOMPARE(account.currency(), updated.currency());
        QCOMPARE(account.initialBalanceMinor(), qint64(25'000));
    }
    QVERIFY(foundUpdated);

    const Category category(
        QStringLiteral("account-update-expense"), QStringLiteral("Expense"),
        CategoryType::Expense);
    QVERIFY(repository.insertCategory(category));
    QVERIFY(repository.insertTransaction(Transaction(
        QStringLiteral("account-update-transaction"), updated.id(), category.id(),
        Money(1'000, Currency::USD), TransactionType::Expense,
        QDateTime::currentDateTimeUtc(), QStringLiteral("Expense"))));

    const Account invalidCurrencyChange(
        updated.id(), updated.name(), updated.assetType(), updated.type(),
        Currency::EUR, updated.initialBalanceMinor());
    QVERIFY(!repository.updateAccount(invalidCurrencyChange));

    accounts = repository.loadAccounts();
    for (const Account& account : accounts) {
        if (account.id() == updated.id()) {
            QCOMPARE(account.currency(), Currency::USD);
        }
    }
}

void FinanceRepositoryTest::deletesAccountWithRelatedOperations()
{
    QTemporaryDir temporaryDirectory;
    QVERIFY(temporaryDirectory.isValid());
    const QString databasePath = temporaryDirectory.filePath(
        QStringLiteral("moneytracker-delete-account-test.sqlite3"));

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));

        const Account source(
            QStringLiteral("account-to-delete"), QStringLiteral("Source"),
            AssetType::Fiat, AccountType::DebitCard, Currency::RUB, 50'000);
        const Account target(
            QStringLiteral("account-to-keep"), QStringLiteral("Target"),
            AssetType::Fiat, AccountType::DebitCard, Currency::RUB, 0);
        const Category category(
            QStringLiteral("delete-account-expense"), QStringLiteral("Expense"),
            CategoryType::Expense);
        QVERIFY(repository.insertAccount(source));
        QVERIFY(repository.insertAccount(target));
        QVERIFY(repository.insertCategory(category));

        const QDateTime occurredAt = QDateTime::currentDateTimeUtc();
        QVERIFY(repository.insertTransaction(Transaction(
            QStringLiteral("delete-account-expense-row"), source.id(), category.id(),
            Money(1'000, Currency::RUB), TransactionType::Expense,
            occurredAt, QStringLiteral("Expense"))));
        QVERIFY(repository.insertTransfer(
            Transaction(
                QStringLiteral("delete-account-transfer-out"), source.id(),
                QStringLiteral("transfer-out"), Money(10'000, Currency::RUB),
                TransactionType::Expense, occurredAt, QStringLiteral("Transfer")),
            Transaction(
                QStringLiteral("delete-account-transfer-in"), target.id(),
                QStringLiteral("transfer-in"), Money(10'000, Currency::RUB),
                TransactionType::Income, occurredAt, QStringLiteral("Transfer"))));

        QVERIFY2(repository.deleteAccount(source.id()),
                 qPrintable(repository.lastError()));
        QVERIFY(repository.loadTransactions().isEmpty());

        const QVector<Account> accounts = repository.loadAccounts();
        bool foundDeleted = false;
        bool foundTarget = false;
        for (const Account& account : accounts) {
            foundDeleted = foundDeleted || account.id() == source.id();
            foundTarget = foundTarget || account.id() == target.id();
        }
        QVERIFY(!foundDeleted);
        QVERIFY(foundTarget);

        QVERIFY(repository.deleteAccount(QStringLiteral("household-eur")));
    }

    {
        FinanceRepository repository(databasePath);
        QVERIFY2(repository.isOpen(), qPrintable(repository.lastError()));
        const QVector<Account> accounts = repository.loadAccounts();
        for (const Account& account : accounts) {
            QVERIFY(account.id() != QStringLiteral("account-to-delete"));
            QVERIFY(account.id() != QStringLiteral("household-eur"));
        }
    }
}

QTEST_GUILESS_MAIN(FinanceRepositoryTest)

#include "FinanceRepositoryTest.moc"
